import { drizzle } from "drizzle-orm/mysql2";
import { config } from "dotenv";

config();

const db = drizzle(process.env.DATABASE_URL);

async function seed() {
  console.log("🌊 Seeding Wave Energy AI database...");

  // Import schema
  const { turbines, energyData, waveData, weatherData, optimizations, forecasts, alerts } = await import("./drizzle/schema.ts");

  try {
    // Seed turbines
    console.log("Adding turbines...");
    const turbineData = [
      {
        name: "Turbine Alpha",
        nameAr: "توربين ألفا",
        serialNumber: "WET-001-A",
        status: "active",
        latitude: 24.7136,
        longitude: 46.6753,
        depth: 25.5,
        capacity: 150.0,
        efficiency: 87.5,
        rotationSpeed: 45.2,
        isOperating: true,
        installationDate: new Date("2024-01-15"),
        lastMaintenanceDate: new Date("2025-12-20"),
        nextMaintenanceDate: new Date("2026-03-20"),
      },
      {
        name: "Turbine Beta",
        nameAr: "توربين بيتا",
        serialNumber: "WET-002-B",
        status: "active",
        latitude: 24.7236,
        longitude: 46.6853,
        depth: 28.3,
        capacity: 150.0,
        efficiency: 89.2,
        rotationSpeed: 48.7,
        isOperating: true,
        installationDate: new Date("2024-01-15"),
        lastMaintenanceDate: new Date("2025-12-20"),
        nextMaintenanceDate: new Date("2026-03-20"),
      },
      {
        name: "Turbine Gamma",
        nameAr: "توربين جاما",
        serialNumber: "WET-003-G",
        status: "maintenance",
        latitude: 24.7036,
        longitude: 46.6653,
        depth: 22.8,
        capacity: 150.0,
        efficiency: 0,
        rotationSpeed: 0,
        isOperating: false,
        installationDate: new Date("2024-02-10"),
        lastMaintenanceDate: new Date("2026-01-15"),
        nextMaintenanceDate: new Date("2026-01-25"),
      },
      {
        name: "Turbine Delta",
        nameAr: "توربين دلتا",
        serialNumber: "WET-004-D",
        status: "active",
        latitude: 24.7336,
        longitude: 46.6953,
        depth: 30.1,
        capacity: 200.0,
        efficiency: 91.8,
        rotationSpeed: 52.3,
        isOperating: true,
        installationDate: new Date("2024-03-20"),
        lastMaintenanceDate: new Date("2025-12-28"),
        nextMaintenanceDate: new Date("2026-03-28"),
      },
    ];

    await db.insert(turbines).values(turbineData);

    // Seed recent energy data for each turbine
    console.log("Adding energy data...");
    const now = Date.now();
    const energyDataPoints = [];
    
    for (let turbineId = 1; turbineId <= 4; turbineId++) {
      const isOperating = turbineId !== 3; // Turbine 3 is in maintenance
      
      for (let i = 0; i < 24; i++) {
        const timestamp = new Date(now - i * 60 * 60 * 1000); // Last 24 hours
        
        energyDataPoints.push({
          turbineId,
          powerOutput: isOperating ? 80 + Math.random() * 70 : 0,
          voltage: isOperating ? 380 + Math.random() * 40 : 0,
          current: isOperating ? 200 + Math.random() * 100 : 0,
          frequency: isOperating ? 49.8 + Math.random() * 0.4 : 0,
          efficiency: isOperating ? 85 + Math.random() * 10 : 0,
          temperature: 18 + Math.random() * 8,
          vibration: isOperating ? 2 + Math.random() * 3 : 0,
          timestamp,
        });
      }
    }
    
    await db.insert(energyData).values(energyDataPoints);

    // Seed wave data
    console.log("Adding wave data...");
    const waveDataPoints = [];
    
    for (let turbineId = 1; turbineId <= 4; turbineId++) {
      for (let i = 0; i < 12; i++) {
        const timestamp = new Date(now - i * 2 * 60 * 60 * 1000); // Last 24 hours, every 2 hours
        
        waveDataPoints.push({
          turbineId,
          waveHeight: 1.5 + Math.random() * 2.5,
          waveAmplitude: 0.8 + Math.random() * 1.2,
          waveFrequency: 0.08 + Math.random() * 0.12,
          wavePeriod: 8 + Math.random() * 6,
          waveDirection: Math.random() * 360,
          currentSpeed: 0.5 + Math.random() * 1.5,
          currentDirection: Math.random() * 360,
          waterTemperature: 19 + Math.random() * 5,
          salinity: 35 + Math.random() * 3,
          timestamp,
        });
      }
    }
    
    await db.insert(waveData).values(waveDataPoints);

    // Seed weather data
    console.log("Adding weather data...");
    const weatherDataPoints = [];
    
    for (let i = 0; i < 12; i++) {
      const timestamp = new Date(now - i * 2 * 60 * 60 * 1000);
      
      weatherDataPoints.push({
        location: "Red Sea Coast",
        latitude: 24.7136,
        longitude: 46.6753,
        windSpeed: 5 + Math.random() * 15,
        windDirection: Math.random() * 360,
        airTemperature: 22 + Math.random() * 10,
        pressure: 1010 + Math.random() * 20,
        humidity: 60 + Math.random() * 30,
        visibility: 8 + Math.random() * 7,
        conditions: ["Clear", "Partly Cloudy", "Cloudy", "Windy"][Math.floor(Math.random() * 4)],
        timestamp,
      });
    }
    
    await db.insert(weatherData).values(weatherDataPoints);

    // Seed AI optimizations
    console.log("Adding AI optimizations...");
    const optimizationData = [
      {
        turbineId: 1,
        recommendationType: "efficiency",
        title: "Increase rotation speed during high wave periods",
        titleAr: "زيادة سرعة الدوران خلال فترات الأمواج العالية",
        description: "AI analysis suggests increasing rotation speed by 15% during the next 6 hours when wave height is predicted to reach 3.5m. This could improve energy capture by 22%.",
        descriptionAr: "يقترح تحليل الذكاء الاصطناعي زيادة سرعة الدوران بنسبة 15٪ خلال الساعات الست القادمة عندما يُتوقع أن يصل ارتفاع الموجة إلى 3.5 متر. قد يؤدي هذا إلى تحسين التقاط الطاقة بنسبة 22٪.",
        priority: "high",
        status: "pending",
        predictedImpact: 22.0,
        confidence: 0.89,
        validFrom: new Date(now),
        validUntil: new Date(now + 6 * 60 * 60 * 1000),
      },
      {
        turbineId: 2,
        recommendationType: "schedule",
        title: "Optimal operation window detected",
        titleAr: "تم اكتشاف نافذة التشغيل المثلى",
        description: "Peak efficiency conditions expected between 14:00-18:00 today. Wave patterns and tidal currents align for maximum energy generation.",
        descriptionAr: "من المتوقع ظروف الكفاءة القصوى بين الساعة 14:00-18:00 اليوم. أنماط الأمواج والتيارات المدية تتماشى لتوليد الطاقة القصوى.",
        priority: "medium",
        status: "pending",
        predictedImpact: 18.5,
        confidence: 0.92,
        validFrom: new Date(now + 2 * 60 * 60 * 1000),
        validUntil: new Date(now + 6 * 60 * 60 * 1000),
      },
      {
        turbineId: 4,
        recommendationType: "maintenance",
        title: "Vibration levels trending upward",
        titleAr: "مستويات الاهتزاز في ارتفاع",
        description: "Vibration sensors show a 12% increase over the past week. Recommend inspection of bearings and blade alignment within 48 hours.",
        descriptionAr: "تظهر أجهزة استشعار الاهتزاز زيادة بنسبة 12٪ خلال الأسبوع الماضي. يوصى بفحص المحامل ومحاذاة الشفرات في غضون 48 ساعة.",
        priority: "high",
        status: "pending",
        predictedImpact: -8.0,
        confidence: 0.85,
        validFrom: new Date(now),
        validUntil: new Date(now + 48 * 60 * 60 * 1000),
      },
    ];
    
    await db.insert(optimizations).values(optimizationData);

    // Seed forecasts
    console.log("Adding forecasts...");
    const forecastData = [];
    
    for (let turbineId = 1; turbineId <= 4; turbineId++) {
      const isOperating = turbineId !== 3;
      
      for (let day = 1; day <= 7; day++) {
        const forecastDate = new Date(now + day * 24 * 60 * 60 * 1000);
        
        forecastData.push({
          turbineId,
          forecastDate,
          predictedPower: isOperating ? 100 + Math.random() * 50 : 0,
          predictedEfficiency: isOperating ? 85 + Math.random() * 10 : 0,
          confidence: 0.75 + Math.random() * 0.2,
          weatherConditions: {
            windSpeed: 8 + Math.random() * 10,
            waveHeight: 2 + Math.random() * 2,
            temperature: 24 + Math.random() * 8,
          },
        });
      }
    }
    
    await db.insert(forecasts).values(forecastData);

    // Seed alerts
    console.log("Adding alerts...");
    const alertData = [
      {
        turbineId: 3,
        alertType: "maintenance",
        severity: "warning",
        title: "Scheduled maintenance in progress",
        titleAr: "الصيانة المجدولة قيد التنفيذ",
        message: "Turbine Gamma is currently undergoing scheduled maintenance. Expected completion: Jan 25, 2026.",
        messageAr: "توربين جاما يخضع حاليًا للصيانة المجدولة. الإنجاز المتوقع: 25 يناير 2026.",
        isRead: false,
        isSent: false,
      },
      {
        turbineId: 1,
        alertType: "optimal_window",
        severity: "info",
        title: "Peak efficiency window approaching",
        titleAr: "نافذة الكفاءة القصوى تقترب",
        message: "Optimal conditions for energy generation expected in 2 hours. Consider maximizing turbine output.",
        messageAr: "من المتوقع ظروف مثالية لتوليد الطاقة خلال ساعتين. فكر في زيادة إنتاج التوربين إلى الحد الأقصى.",
        isRead: false,
        isSent: false,
      },
      {
        turbineId: 4,
        alertType: "anomaly",
        severity: "warning",
        title: "Unusual vibration pattern detected",
        titleAr: "تم اكتشاف نمط اهتزاز غير عادي",
        message: "AI anomaly detection has identified irregular vibration patterns. Monitoring system recommends inspection.",
        messageAr: "اكتشف نظام الذكاء الاصطناعي أنماط اهتزاز غير منتظمة. يوصي نظام المراقبة بالفحص.",
        isRead: false,
        isSent: false,
      },
    ];
    
    await db.insert(alerts).values(alertData);

    console.log("✅ Database seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
