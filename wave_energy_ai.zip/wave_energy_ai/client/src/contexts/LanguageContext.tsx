import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { trpc } from "@/lib/trpc";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    // Navigation
    "nav.dashboard": "لوحة التحكم",
    "nav.turbines": "التوربينات",
    "nav.ai_assistant": "المساعد الذكي",
    "nav.optimizations": "التحسين الذكي",
    "nav.analytics": "التحليلات",
    "nav.settings": "الإعدادات",
    "nav.logout": "تسجيل الخروج",
    
    // Dashboard
    "dashboard.title": "لوحة التحكم الرئيسية",
    "dashboard.subtitle": "مراقبة وتحسين نظام توليد الطاقة من الأمواج البحرية في الوقت الفعلي",
    "dashboard.total_output": "إجمالي الطاقة المولدة",
    "dashboard.active_turbines": "التوربينات النشطة",
    "dashboard.efficiency": "الكفاءة الإجمالية",
    "dashboard.alerts": "التنبيهات النشطة",
    "dashboard.last_24h": "آخر 24 ساعة",
    "dashboard.currently_operating": "قيد التشغيل حالياً",
    "dashboard.system_average": "متوسط النظام",
    "dashboard.requires_attention": "تتطلب الانتباه",
    
    // 3D Visualization
    "3d.title": "التصور ثلاثي الأبعاد للتوربينات البحرية",
    "3d.description": "عرض تفاعلي ثلاثي الأبعاد لمنشآت التوربينات. انقر على أي توربين لعرض التفاصيل الفنية.",
    "3d.select_turbine": "اختر توربيناً",
    "3d.no_selection": "لم يتم اختيار توربين",
    "3d.click_to_select": "انقر على توربين في العرض ثلاثي الأبعاد",
    
    // Turbine Details
    "turbine.status": "حالة التشغيل",
    "turbine.power_output": "الطاقة المولدة",
    "turbine.efficiency": "الكفاءة",
    "turbine.rotation_speed": "سرعة الدوران",
    "turbine.temperature": "درجة الحرارة",
    "turbine.capacity": "القدرة الاستيعابية",
    "turbine.depth": "عمق التثبيت",
    "turbine.location": "الموقع الجغرافي",
    "turbine.serial": "الرقم التسلسلي",
    "turbine.installation_date": "تاريخ التركيب",
    "turbine.next_maintenance": "الصيانة القادمة",
    
    // Wave Conditions
    "wave.title": "ظروف الأمواج والتيارات",
    "wave.height": "ارتفاع الموجة",
    "wave.frequency": "تردد الموجة",
    "wave.current_speed": "سرعة التيار",
    "wave.direction": "اتجاه الموجة",
    "wave.amplitude": "سعة الموجة",
    
    // Turbine Control
    "turbines.title": "إدارة وتحكم التوربينات",
    "turbines.subtitle": "مراقبة والتحكم في عمليات التوربينات الفردية",
    "turbines.start": "تشغيل",
    "turbines.stop": "إيقاف",
    "turbines.maintenance": "صيانة",
    "turbines.settings": "الإعدادات",
    "turbines.schedule_maintenance": "جدولة الصيانة",
    "turbines.in_maintenance": "قيد الصيانة حالياً",
    "turbines.cannot_operate": "لا يمكن تشغيل التوربين في حالة الصيانة أو الخطأ",
    
    // Status
    "status.active": "نشط",
    "status.inactive": "غير نشط",
    "status.maintenance": "صيانة",
    "status.error": "خطأ",
    "status.operating": "قيد التشغيل",
    "status.stopped": "متوقف",
    
    // AI Optimization
    "ai.title": "التحسين بالذكاء الاصطناعي",
    "ai.subtitle": "توصيات ذكية مدعومة بالذكاء الاصطناعي لتحقيق أقصى كفاءة في توليد الطاقة",
    "ai.recommendations": "التوصيات الذكية",
    "ai.generate": "توليد توصيات جديدة",
    "ai.apply": "تطبيق التوصية",
    "ai.reject": "رفض",
    "ai.predicted_impact": "التأثير المتوقع",
    "ai.confidence": "مستوى الثقة",
    "ai.time_remaining": "الوقت المتبقي",
    "ai.valid_period": "فترة الصلاحية",
    "ai.no_recommendations": "لا توجد توصيات نشطة",
    "ai.generate_new": "قم بتوليد توصيات ذكية جديدة للتوربينات لتحسين الأداء والكفاءة",
    
    // AI Assistant
    "assistant.title": "المساعد الذكي",
    "assistant.subtitle": "اطرح أسئلة حول بيانات الطاقة، أداء التوربينات، واحصل على رؤى ذكية",
    "assistant.conversations": "المحادثات",
    "assistant.new_chat": "محادثة جديدة",
    "assistant.type_message": "اكتب رسالتك...",
    "assistant.start_conversation": "ابدأ محادثة",
    "assistant.ask_anything": "اسألني أي شيء عن نظام الطاقة من الأمواج",
    "assistant.example_questions": "أمثلة على الأسئلة:",
    "assistant.example_1": "ما هي الكفاءة الحالية للتوربين ألفا؟",
    "assistant.example_2": "أظهر لي توقعات الطاقة للأسبوع القادم",
    "assistant.example_3": "أي توربين يحتاج إلى صيانة؟",
    "assistant.example_4": "حلل ظروف الأمواج للتشغيل الأمثل",
    
    // Charts & Analytics
    "chart.power_output": "الطاقة المولدة (24 ساعة)",
    "chart.efficiency": "الكفاءة",
    "chart.historical": "البيانات التاريخية",
    "chart.real_time": "الوقت الفعلي",
    "chart.forecast": "التوقعات",
    
    // Alerts
    "alerts.title": "التنبيهات والإشعارات",
    "alerts.recent": "التنبيهات الأخيرة",
    "alerts.critical": "حرج",
    "alerts.error": "خطأ",
    "alerts.warning": "تحذير",
    "alerts.info": "معلومة",
    "alerts.unread": "غير مقروء",
    "alerts.mark_read": "تحديد كمقروء",
    
    // Priority
    "priority.low": "منخفض",
    "priority.medium": "متوسط",
    "priority.high": "عالي",
    "priority.critical": "حرج",
    
    // Recommendation Types
    "rec_type.schedule": "جدولة",
    "rec_type.maintenance": "صيانة",
    "rec_type.efficiency": "كفاءة",
    "rec_type.safety": "سلامة",
    
    // Actions
    "action.save": "حفظ",
    "action.cancel": "إلغاء",
    "action.delete": "حذف",
    "action.edit": "تعديل",
    "action.view": "عرض",
    "action.download": "تحميل",
    "action.refresh": "تحديث",
    "action.filter": "تصفية",
    "action.search": "بحث",
    "action.send": "إرسال",
    
    // Messages
    "msg.success": "تمت العملية بنجاح",
    "msg.error": "حدث خطأ",
    "msg.loading": "جاري التحميل...",
    "msg.no_data": "لا توجد بيانات",
    "msg.please_login": "الرجاء تسجيل الدخول",
    
    // Units
    "unit.kw": "كيلووات",
    "unit.rpm": "دورة/دقيقة",
    "unit.celsius": "درجة مئوية",
    "unit.meter": "متر",
    "unit.meters_per_second": "م/ث",
    "unit.hertz": "هرتز",
    "unit.percent": "%",
    "unit.hours": "ساعة",
    
    // Technical Explanations
    "explain.turbine": "التوربين البحري هو جهاز يحول الطاقة الحركية من الأمواج والتيارات البحرية إلى طاقة كهربائية نظيفة ومتجددة.",
    "explain.efficiency": "الكفاءة هي نسبة الطاقة الكهربائية المولدة إلى الطاقة الحركية المتاحة من الأمواج، وتتأثر بعوامل عديدة مثل سرعة التيار وارتفاع الموجة.",
    "explain.optimization": "يستخدم نظام التحسين الذكي خوارزميات الذكاء الاصطناعي لتحليل بيانات الأمواج والطقس والتنبؤ بأفضل أوقات التشغيل لزيادة إنتاج الطاقة.",
    "explain.wave_height": "ارتفاع الموجة هو المسافة العمودية بين قمة الموجة وقاعها، ويؤثر بشكل مباشر على كمية الطاقة المتاحة للتوليد.",
    "explain.rotation_speed": "سرعة دوران التوربين تقاس بالدورات في الدقيقة (RPM) وتعتمد على قوة التيار البحري وارتفاع الأمواج.",
  },
  en: {
    // Navigation
    "nav.dashboard": "Dashboard",
    "nav.turbines": "Turbines",
    "nav.ai_assistant": "AI Assistant",
    "nav.optimizations": "AI Optimization",
    "nav.analytics": "Analytics",
    "nav.settings": "Settings",
    "nav.logout": "Logout",
    
    // Dashboard
    "dashboard.title": "Wave Energy Dashboard",
    "dashboard.subtitle": "Real-time monitoring and AI-powered optimization for marine wave energy systems",
    "dashboard.total_output": "Total Power Output",
    "dashboard.active_turbines": "Active Turbines",
    "dashboard.efficiency": "Average Efficiency",
    "dashboard.alerts": "Active Alerts",
    "dashboard.last_24h": "Last 24 hours",
    "dashboard.currently_operating": "Currently operating",
    "dashboard.system_average": "System-wide average",
    "dashboard.requires_attention": "Requires attention",
    
    // 3D Visualization
    "3d.title": "3D Ocean Turbine Visualization",
    "3d.description": "Interactive 3D view of turbine installations. Click on a turbine to view details.",
    "3d.select_turbine": "Select a Turbine",
    "3d.no_selection": "No turbine selected",
    "3d.click_to_select": "Click on a turbine in the 3D view",
    
    // Turbine Details
    "turbine.status": "Status",
    "turbine.power_output": "Power Output",
    "turbine.efficiency": "Efficiency",
    "turbine.rotation_speed": "Rotation Speed",
    "turbine.temperature": "Temperature",
    "turbine.capacity": "Capacity",
    "turbine.depth": "Depth",
    "turbine.location": "Location",
    "turbine.serial": "Serial Number",
    "turbine.installation_date": "Installation Date",
    "turbine.next_maintenance": "Next Maintenance",
    
    // Wave Conditions
    "wave.title": "Wave & Current Conditions",
    "wave.height": "Wave Height",
    "wave.frequency": "Wave Frequency",
    "wave.current_speed": "Current Speed",
    "wave.direction": "Wave Direction",
    "wave.amplitude": "Wave Amplitude",
    
    // Turbine Control
    "turbines.title": "Turbine Control & Management",
    "turbines.subtitle": "Monitor and control individual turbine operations",
    "turbines.start": "Start",
    "turbines.stop": "Stop",
    "turbines.maintenance": "Maintenance",
    "turbines.settings": "Settings",
    "turbines.schedule_maintenance": "Schedule Maintenance",
    "turbines.in_maintenance": "Currently in Maintenance",
    "turbines.cannot_operate": "Cannot operate turbine in maintenance or error state",
    
    // Status
    "status.active": "Active",
    "status.inactive": "Inactive",
    "status.maintenance": "Maintenance",
    "status.error": "Error",
    "status.operating": "Operating",
    "status.stopped": "Stopped",
    
    // AI Optimization
    "ai.title": "AI Optimization",
    "ai.subtitle": "AI-powered optimization recommendations for maximum energy efficiency",
    "ai.recommendations": "AI Recommendations",
    "ai.generate": "Generate New Recommendations",
    "ai.apply": "Apply Recommendation",
    "ai.reject": "Reject",
    "ai.predicted_impact": "Predicted Impact",
    "ai.confidence": "AI Confidence",
    "ai.time_remaining": "Time Remaining",
    "ai.valid_period": "Valid Period",
    "ai.no_recommendations": "No Active Recommendations",
    "ai.generate_new": "Generate new AI recommendations for your turbines to optimize performance and efficiency",
    
    // AI Assistant
    "assistant.title": "AI Assistant",
    "assistant.subtitle": "Ask questions about energy data, turbine performance, and get AI-powered insights",
    "assistant.conversations": "Conversations",
    "assistant.new_chat": "New Chat",
    "assistant.type_message": "Type your message...",
    "assistant.start_conversation": "Start a conversation",
    "assistant.ask_anything": "Ask me anything about your wave energy system",
    "assistant.example_questions": "Example questions:",
    "assistant.example_1": "What is the current efficiency of Turbine Alpha?",
    "assistant.example_2": "Show me the power output forecast for next week",
    "assistant.example_3": "Which turbine needs maintenance?",
    "assistant.example_4": "Analyze the wave conditions for optimal operation",
    
    // Charts & Analytics
    "chart.power_output": "Power Output (24h)",
    "chart.efficiency": "Efficiency",
    "chart.historical": "Historical Data",
    "chart.real_time": "Real-time",
    "chart.forecast": "Forecast",
    
    // Alerts
    "alerts.title": "Alerts & Notifications",
    "alerts.recent": "Recent Alerts",
    "alerts.critical": "Critical",
    "alerts.error": "Error",
    "alerts.warning": "Warning",
    "alerts.info": "Info",
    "alerts.unread": "Unread",
    "alerts.mark_read": "Mark as Read",
    
    // Priority
    "priority.low": "Low",
    "priority.medium": "Medium",
    "priority.high": "High",
    "priority.critical": "Critical",
    
    // Recommendation Types
    "rec_type.schedule": "Schedule",
    "rec_type.maintenance": "Maintenance",
    "rec_type.efficiency": "Efficiency",
    "rec_type.safety": "Safety",
    
    // Actions
    "action.save": "Save",
    "action.cancel": "Cancel",
    "action.delete": "Delete",
    "action.edit": "Edit",
    "action.view": "View",
    "action.download": "Download",
    "action.refresh": "Refresh",
    "action.filter": "Filter",
    "action.search": "Search",
    "action.send": "Send",
    
    // Messages
    "msg.success": "Operation completed successfully",
    "msg.error": "An error occurred",
    "msg.loading": "Loading...",
    "msg.no_data": "No data available",
    "msg.please_login": "Please log in",
    
    // Units
    "unit.kw": "kW",
    "unit.rpm": "RPM",
    "unit.celsius": "°C",
    "unit.meter": "m",
    "unit.meters_per_second": "m/s",
    "unit.hertz": "Hz",
    "unit.percent": "%",
    "unit.hours": "h",
    
    // Technical Explanations
    "explain.turbine": "A marine turbine is a device that converts kinetic energy from ocean waves and currents into clean, renewable electrical energy.",
    "explain.efficiency": "Efficiency is the ratio of electrical energy generated to the kinetic energy available from waves, affected by factors such as current speed and wave height.",
    "explain.optimization": "The AI optimization system uses machine learning algorithms to analyze wave and weather data and predict the best operating times to maximize energy production.",
    "explain.wave_height": "Wave height is the vertical distance between the crest and trough of a wave, directly affecting the amount of energy available for generation.",
    "explain.rotation_speed": "Turbine rotation speed is measured in revolutions per minute (RPM) and depends on the strength of ocean currents and wave height.",
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("ar"); // Default to Arabic
  
  const setLanguageMutation = trpc.auth.setLanguage.useMutation();
  
  // Load language from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("language") as Language;
    if (saved && (saved === "ar" || saved === "en")) {
      setLanguageState(saved);
      document.documentElement.lang = saved;
      document.documentElement.dir = saved === "ar" ? "rtl" : "ltr";
    } else {
      // Default to Arabic
      document.documentElement.lang = "ar";
      document.documentElement.dir = "rtl";
    }
  }, []);
  
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    
    // Save to server if user is authenticated
    try {
      setLanguageMutation.mutate({ language: lang });
    } catch {
      // Ignore error if not authenticated
    }
  };
  
  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key;
  };
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}
