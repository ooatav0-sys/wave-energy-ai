import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";
import { Sparkles, TrendingUp, TrendingDown, Clock, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

export default function Optimizations() {
  const { t, language } = useLanguage();
  
  const utils = trpc.useUtils();
  const { data: turbines } = trpc.turbines.list.useQuery();
  const { data: optimizations, isLoading } = trpc.optimizations.active.useQuery({});
  
  const updateStatus = trpc.optimizations.updateStatus.useMutation({
    onSuccess: () => {
      utils.optimizations.active.invalidate();
      toast.success("Optimization status updated");
    },
    onError: (error) => {
      toast.error("Failed to update: " + error.message);
    },
  });
  
  const generateOptimization = trpc.optimizations.generate.useMutation({
    onSuccess: () => {
      utils.optimizations.active.invalidate();
      toast.success("New optimization recommendation generated");
    },
    onError: (error) => {
      toast.error("Failed to generate: " + error.message);
    },
  });
  
  const handleApply = (id: number) => {
    updateStatus.mutate({ id, status: "applied" });
  };
  
  const handleReject = (id: number) => {
    updateStatus.mutate({ id, status: "rejected" });
  };
  
  const handleGenerate = (turbineId: number) => {
    generateOptimization.mutate({ turbineId });
  };
  
  const priorityColors = {
    low: "bg-blue-500",
    medium: "bg-amber-500",
    high: "bg-orange-500",
    critical: "bg-red-500",
  };
  
  const typeIcons = {
    schedule: Clock,
    maintenance: Sparkles,
    efficiency: TrendingUp,
    safety: XCircle,
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 dark:from-slate-950 dark:via-blue-950 dark:to-cyan-950">
      <div className="container py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
            {t("ai.recommendations")}
          </h1>
          <p className="text-muted-foreground">
            AI-powered optimization recommendations for maximum energy efficiency
          </p>
        </div>
        
        {/* Generate New Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Generate AI Recommendations</CardTitle>
            <CardDescription>
              Use AI to analyze current conditions and generate optimization suggestions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {turbines?.map((turbine) => (
                <Button
                  key={turbine.id}
                  variant="outline"
                  onClick={() => handleGenerate(turbine.id)}
                  disabled={generateOptimization.isPending}
                >
                  {generateOptimization.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4 mr-2" />
                  )}
                  {turbine.name}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Active Recommendations */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Active Recommendations</h2>
          
          {isLoading ? (
            <div className="grid gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-6 bg-muted rounded w-3/4"></div>
                    <div className="h-4 bg-muted rounded w-1/2 mt-2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="h-20 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : optimizations && optimizations.length > 0 ? (
            <div className="grid gap-4">
              {optimizations.map((opt) => {
                const TypeIcon = typeIcons[opt.recommendationType];
                const turbine = turbines?.find(t => t.id === opt.turbineId);
                const title = language === "ar" && opt.titleAr ? opt.titleAr : opt.title;
                const description = language === "ar" && opt.descriptionAr ? opt.descriptionAr : opt.description;
                
                const timeRemaining = new Date(opt.validUntil).getTime() - Date.now();
                const totalTime = new Date(opt.validUntil).getTime() - new Date(opt.validFrom).getTime();
                const timeProgress = Math.max(0, Math.min(100, ((totalTime - timeRemaining) / totalTime) * 100));
                
                return (
                  <Card 
                    key={opt.id}
                    className={`border-l-4 ${
                      opt.priority === "critical" ? "border-l-red-500" :
                      opt.priority === "high" ? "border-l-orange-500" :
                      opt.priority === "medium" ? "border-l-amber-500" :
                      "border-l-blue-500"
                    }`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2">
                            <TypeIcon className="h-5 w-5 text-primary" />
                            <CardTitle className="text-xl">{title}</CardTitle>
                          </div>
                          <CardDescription>
                            {turbine?.name} • {opt.recommendationType}
                          </CardDescription>
                        </div>
                        <Badge className={priorityColors[opt.priority]}>
                          {opt.priority.toUpperCase()}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-sm text-muted-foreground">{description}</p>
                      
                      {/* Metrics */}
                      <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-lg">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">Predicted Impact</p>
                          <div className="flex items-center justify-center gap-1">
                            {opt.predictedImpact > 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-500" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-500" />
                            )}
                            <p className={`text-lg font-bold ${
                              opt.predictedImpact > 0 ? "text-green-500" : "text-red-500"
                            }`}>
                              {opt.predictedImpact > 0 ? "+" : ""}{opt.predictedImpact.toFixed(1)}%
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">AI Confidence</p>
                          <p className="text-lg font-bold">{(opt.confidence * 100).toFixed(0)}%</p>
                          <Progress value={opt.confidence * 100} className="h-1 mt-1" />
                        </div>
                        
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">Time Remaining</p>
                          <p className="text-lg font-bold">
                            {Math.ceil(timeRemaining / (1000 * 60 * 60))}h
                          </p>
                          <Progress value={timeProgress} className="h-1 mt-1" />
                        </div>
                      </div>
                      
                      {/* Validity Period */}
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>
                          Valid: {new Date(opt.validFrom).toLocaleString()} - {new Date(opt.validUntil).toLocaleString()}
                        </span>
                      </div>
                      
                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          className="flex-1"
                          onClick={() => handleApply(opt.id)}
                          disabled={updateStatus.isPending}
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          {t("ai.apply")}
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleReject(opt.id)}
                          disabled={updateStatus.isPending}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          {t("ai.reject")}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Sparkles className="h-16 w-16 text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">No Active Recommendations</p>
                <p className="text-sm text-muted-foreground text-center max-w-md">
                  Generate new AI recommendations for your turbines to optimize performance and efficiency
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
