import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";
import { Play, Pause, Settings, Wrench, MapPin, Calendar } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function TurbineControl() {
  const { t } = useLanguage();
  const [selectedTurbine, setSelectedTurbine] = useState<number | null>(null);
  
  const utils = trpc.useUtils();
  const { data: turbines, isLoading } = trpc.turbines.list.useQuery();
  
  const updateStatus = trpc.turbines.updateStatus.useMutation({
    onSuccess: () => {
      utils.turbines.list.invalidate();
      toast.success("Turbine status updated successfully");
    },
    onError: (error) => {
      toast.error("Failed to update turbine: " + error.message);
    },
  });
  
  const handleToggleTurbine = (turbineId: number, currentStatus: string, isOperating: boolean) => {
    if (currentStatus === "maintenance" || currentStatus === "error") {
      toast.error("Cannot operate turbine in maintenance or error state");
      return;
    }
    
    const newStatus = isOperating ? "inactive" : "active";
    const newOperating = !isOperating;
    
    updateStatus.mutate({
      id: turbineId,
      status: newStatus as any,
      isOperating: newOperating,
    });
  };
  
  const handleSetMaintenance = (turbineId: number) => {
    updateStatus.mutate({
      id: turbineId,
      status: "maintenance",
      isOperating: false,
    });
  };
  
  const statusColors = {
    active: "bg-green-500 text-white",
    inactive: "bg-gray-500 text-white",
    maintenance: "bg-amber-500 text-white",
    error: "bg-red-500 text-white",
  };
  
  const statusIcons = {
    active: Play,
    inactive: Pause,
    maintenance: Wrench,
    error: Settings,
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 dark:from-slate-950 dark:via-blue-950 dark:to-cyan-950">
      <div className="container py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
            {t("turbines.title")}
          </h1>
          <p className="text-muted-foreground">
            Monitor and control individual turbine operations
          </p>
        </div>
        
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4"></div>
                  <div className="h-4 bg-muted rounded w-1/2 mt-2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {turbines?.map((turbine) => {
              const StatusIcon = statusIcons[turbine.status];
              
              return (
                <Card 
                  key={turbine.id} 
                  className={`border-l-4 transition-all hover:shadow-lg ${
                    turbine.status === "active" ? "border-l-green-500" :
                    turbine.status === "inactive" ? "border-l-gray-500" :
                    turbine.status === "maintenance" ? "border-l-amber-500" :
                    "border-l-red-500"
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl">{turbine.name}</CardTitle>
                        <CardDescription className="text-xs">
                          {turbine.serialNumber}
                        </CardDescription>
                      </div>
                      <Badge className={statusColors[turbine.status]}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {turbine.status.toUpperCase()}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    {/* Location */}
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>
                        {turbine.latitude.toFixed(4)}°, {turbine.longitude.toFixed(4)}°
                      </span>
                    </div>
                    
                    {/* Metrics */}
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-muted-foreground">Capacity</p>
                        <p className="font-semibold">{turbine.capacity} kW</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Efficiency</p>
                        <p className="font-semibold">{turbine.efficiency.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Depth</p>
                        <p className="font-semibold">{turbine.depth} m</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">RPM</p>
                        <p className="font-semibold">{turbine.rotationSpeed.toFixed(1)}</p>
                      </div>
                    </div>
                    
                    {/* Maintenance Info */}
                    {turbine.nextMaintenanceDate && (
                      <div className="flex items-center gap-2 text-sm p-2 bg-muted rounded">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-xs text-muted-foreground">Next Maintenance</p>
                          <p className="font-medium">
                            {new Date(turbine.nextMaintenanceDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {/* Control Buttons */}
                    <div className="flex gap-2 pt-2">
                      <Button
                        variant={turbine.isOperating ? "destructive" : "default"}
                        className="flex-1"
                        onClick={() => handleToggleTurbine(turbine.id, turbine.status, turbine.isOperating)}
                        disabled={updateStatus.isPending || turbine.status === "maintenance" || turbine.status === "error"}
                      >
                        {turbine.isOperating ? (
                          <>
                            <Pause className="h-4 w-4 mr-2" />
                            Stop
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Start
                          </>
                        )}
                      </Button>
                      
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="icon">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>{turbine.name} Settings</DialogTitle>
                            <DialogDescription>
                              Manage turbine configuration and maintenance
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <h4 className="font-medium">Turbine Information</h4>
                              <div className="grid grid-cols-2 gap-2 text-sm">
                                <div>
                                  <p className="text-muted-foreground">Serial Number</p>
                                  <p className="font-medium">{turbine.serialNumber}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Installation Date</p>
                                  <p className="font-medium">
                                    {new Date(turbine.installationDate).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <h4 className="font-medium">Maintenance Actions</h4>
                              <Button
                                variant="outline"
                                className="w-full"
                                onClick={() => {
                                  handleSetMaintenance(turbine.id);
                                }}
                                disabled={turbine.status === "maintenance"}
                              >
                                <Wrench className="h-4 w-4 mr-2" />
                                {turbine.status === "maintenance" 
                                  ? "Currently in Maintenance" 
                                  : "Schedule Maintenance"}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
