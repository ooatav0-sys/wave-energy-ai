import { Info, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

interface InfoPanelProps {
  title: string;
  content: string;
  technicalDetails?: {
    label: string;
    value: string;
  }[];
}

export default function InfoPanel({ title, content, technicalDetails }: InfoPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { language } = useLanguage();
  
  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 rounded-full"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Info className="h-4 w-4 text-primary" />
      </Button>
      
      {isOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Panel */}
          <div 
            className={`fixed ${language === "ar" ? "left-4" : "right-4"} top-20 z-50 w-96 max-w-[calc(100vw-2rem)] technical-tooltip rounded-lg p-6 animate-in slide-in-from-right-5`}
          >
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-primary">{title}</h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              {content}
            </p>
            
            {technicalDetails && technicalDetails.length > 0 && (
              <div className="space-y-2 pt-4 border-t border-border">
                <h4 className="text-sm font-semibold text-foreground">
                  {language === "ar" ? "المواصفات الفنية:" : "Technical Specifications:"}
                </h4>
                {technicalDetails.map((detail, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{detail.label}</span>
                    <span className="font-mono text-foreground">{detail.value}</span>
                  </div>
                ))}
              </div>
            )}
            
            {/* Decorative corner */}
            <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <path
                  d="M 0 0 L 100 0 L 100 100 Z"
                  fill="currentColor"
                  className="text-primary"
                />
              </svg>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
