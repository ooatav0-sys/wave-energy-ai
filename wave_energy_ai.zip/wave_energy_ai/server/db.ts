import { eq, desc, and, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  turbines, InsertTurbine, Turbine,
  energyData, InsertEnergyData,
  waveData, InsertWaveData,
  weatherData, InsertWeatherData,
  optimizations, InsertOptimization,
  forecasts, InsertForecast,
  alerts, InsertAlert,
  performanceReports, InsertPerformanceReport,
  chatSessions, InsertChatSession,
  chatMessages, InsertChatMessage
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============= USER OPERATIONS =============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (user.preferredLanguage !== undefined) {
      values.preferredLanguage = user.preferredLanguage;
      updateSet.preferredLanguage = user.preferredLanguage;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserLanguage(userId: number, language: "en" | "ar") {
  const db = await getDb();
  if (!db) return;
  
  await db.update(users).set({ preferredLanguage: language }).where(eq(users.id, userId));
}

// ============= TURBINE OPERATIONS =============

export async function getAllTurbines() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(turbines).orderBy(turbines.name);
}

export async function getTurbineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(turbines).where(eq(turbines.id, id)).limit(1);
  return result[0];
}

export async function createTurbine(data: InsertTurbine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(turbines).values(data);
  return result;
}

export async function updateTurbine(id: number, data: Partial<Turbine>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(turbines).set(data).where(eq(turbines.id, id));
}

export async function updateTurbineStatus(id: number, status: "active" | "inactive" | "maintenance" | "error", isOperating: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(turbines).set({ status, isOperating }).where(eq(turbines.id, id));
}

// ============= ENERGY DATA OPERATIONS =============

export async function insertEnergyData(data: InsertEnergyData) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(energyData).values(data);
}

export async function getLatestEnergyData(turbineId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(energyData)
    .where(eq(energyData.turbineId, turbineId))
    .orderBy(desc(energyData.timestamp))
    .limit(1);
  
  return result[0];
}

export async function getEnergyDataRange(turbineId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(energyData)
    .where(
      and(
        eq(energyData.turbineId, turbineId),
        gte(energyData.timestamp, startDate),
        lte(energyData.timestamp, endDate)
      )
    )
    .orderBy(energyData.timestamp);
}

export async function getTotalEnergyOutput() {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db
    .select({
      total: sql<number>`SUM(${energyData.powerOutput})`
    })
    .from(energyData)
    .where(gte(energyData.timestamp, new Date(Date.now() - 24 * 60 * 60 * 1000)));
  
  return result[0]?.total || 0;
}

// ============= WAVE DATA OPERATIONS =============

export async function insertWaveData(data: InsertWaveData) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(waveData).values(data);
}

export async function getLatestWaveData(turbineId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(waveData)
    .where(eq(waveData.turbineId, turbineId))
    .orderBy(desc(waveData.timestamp))
    .limit(1);
  
  return result[0];
}

export async function getWaveDataRange(turbineId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(waveData)
    .where(
      and(
        eq(waveData.turbineId, turbineId),
        gte(waveData.timestamp, startDate),
        lte(waveData.timestamp, endDate)
      )
    )
    .orderBy(waveData.timestamp);
}

// ============= WEATHER DATA OPERATIONS =============

export async function insertWeatherData(data: InsertWeatherData) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(weatherData).values(data);
}

export async function getLatestWeatherData(location: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(weatherData)
    .where(eq(weatherData.location, location))
    .orderBy(desc(weatherData.timestamp))
    .limit(1);
  
  return result[0];
}

// ============= OPTIMIZATION OPERATIONS =============

export async function createOptimization(data: InsertOptimization) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(optimizations).values(data);
  return result;
}

export async function getActiveOptimizations(turbineId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  const conditions = [
    eq(optimizations.status, "pending"),
    lte(optimizations.validFrom, now),
    gte(optimizations.validUntil, now)
  ];
  
  if (turbineId !== undefined) {
    conditions.push(eq(optimizations.turbineId, turbineId));
  }
  
  return await db
    .select()
    .from(optimizations)
    .where(and(...conditions))
    .orderBy(desc(optimizations.priority), desc(optimizations.confidence));
}

export async function updateOptimizationStatus(id: number, status: "pending" | "applied" | "rejected" | "expired") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: any = { status };
  if (status === "applied") {
    updateData.appliedAt = new Date();
  }
  
  await db.update(optimizations).set(updateData).where(eq(optimizations.id, id));
}

// ============= FORECAST OPERATIONS =============

export async function createForecast(data: InsertForecast) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(forecasts).values(data);
}

export async function getUpcomingForecasts(turbineId: number, days: number = 7) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  const futureDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
  
  return await db
    .select()
    .from(forecasts)
    .where(
      and(
        eq(forecasts.turbineId, turbineId),
        gte(forecasts.forecastDate, now),
        lte(forecasts.forecastDate, futureDate)
      )
    )
    .orderBy(forecasts.forecastDate);
}

// ============= ALERT OPERATIONS =============

export async function createAlert(data: InsertAlert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(alerts).values(data);
  return result;
}

export async function getUnreadAlerts(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(alerts)
    .where(eq(alerts.isRead, false))
    .orderBy(desc(alerts.createdAt))
    .limit(limit);
}

export async function markAlertAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id));
}

export async function markAlertAsSent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(alerts).set({ isSent: true, sentAt: new Date() }).where(eq(alerts.id, id));
}

// ============= PERFORMANCE REPORT OPERATIONS =============

export async function createPerformanceReport(data: InsertPerformanceReport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(performanceReports).values(data);
}

export async function getPerformanceReports(turbineId?: number, reportType?: string) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(performanceReports);
  
  const conditions = [];
  if (turbineId !== undefined) {
    conditions.push(eq(performanceReports.turbineId, turbineId));
  }
  if (reportType) {
    conditions.push(eq(performanceReports.reportType, reportType as any));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(performanceReports.createdAt)).limit(20);
}

// ============= CHAT OPERATIONS =============

export async function createChatSession(userId: number, language: "en" | "ar" = "en") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatSessions).values({ userId, language });
  return result;
}

export async function getChatSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(chatSessions)
    .where(eq(chatSessions.userId, userId))
    .orderBy(desc(chatSessions.updatedAt))
    .limit(20);
}

export async function insertChatMessage(data: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(chatMessages).values(data);
}

export async function getChatMessages(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(chatMessages.createdAt);
}

export async function updateChatSessionTitle(sessionId: number, title: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(chatSessions).set({ title }).where(eq(chatSessions.id, sessionId));
}
