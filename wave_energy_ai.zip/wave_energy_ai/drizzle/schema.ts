import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  preferredLanguage: mysqlEnum("preferredLanguage", ["en", "ar"]).default("en").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Wave turbine installations
 */
export const turbines = mysqlTable("turbines", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  nameAr: varchar("nameAr", { length: 255 }),
  serialNumber: varchar("serialNumber", { length: 100 }).notNull().unique(),
  status: mysqlEnum("status", ["active", "inactive", "maintenance", "error"]).default("active").notNull(),
  latitude: float("latitude").notNull(),
  longitude: float("longitude").notNull(),
  depth: float("depth").notNull(), // meters
  capacity: float("capacity").notNull(), // kW
  efficiency: float("efficiency").default(0).notNull(), // percentage
  rotationSpeed: float("rotationSpeed").default(0).notNull(), // RPM
  isOperating: boolean("isOperating").default(false).notNull(),
  lastMaintenanceDate: timestamp("lastMaintenanceDate"),
  nextMaintenanceDate: timestamp("nextMaintenanceDate"),
  installationDate: timestamp("installationDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Turbine = typeof turbines.$inferSelect;
export type InsertTurbine = typeof turbines.$inferInsert;

/**
 * Real-time energy generation data
 */
export const energyData = mysqlTable("energyData", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").notNull().references(() => turbines.id),
  powerOutput: float("powerOutput").notNull(), // kW
  voltage: float("voltage").notNull(), // V
  current: float("current").notNull(), // A
  frequency: float("frequency").notNull(), // Hz
  efficiency: float("efficiency").notNull(), // percentage
  temperature: float("temperature").notNull(), // Celsius
  vibration: float("vibration").notNull(), // mm/s
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type EnergyData = typeof energyData.$inferSelect;
export type InsertEnergyData = typeof energyData.$inferInsert;

/**
 * Wave and ocean sensor data
 */
export const waveData = mysqlTable("waveData", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").notNull().references(() => turbines.id),
  waveHeight: float("waveHeight").notNull(), // meters
  waveAmplitude: float("waveAmplitude").notNull(), // meters
  waveFrequency: float("waveFrequency").notNull(), // Hz
  wavePeriod: float("wavePeriod").notNull(), // seconds
  waveDirection: float("waveDirection").notNull(), // degrees
  currentSpeed: float("currentSpeed").notNull(), // m/s
  currentDirection: float("currentDirection").notNull(), // degrees
  waterTemperature: float("waterTemperature").notNull(), // Celsius
  salinity: float("salinity").notNull(), // PSU
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type WaveData = typeof waveData.$inferSelect;
export type InsertWaveData = typeof waveData.$inferInsert;

/**
 * Weather and environmental data
 */
export const weatherData = mysqlTable("weatherData", {
  id: int("id").autoincrement().primaryKey(),
  location: varchar("location", { length: 255 }).notNull(),
  latitude: float("latitude").notNull(),
  longitude: float("longitude").notNull(),
  windSpeed: float("windSpeed").notNull(), // m/s
  windDirection: float("windDirection").notNull(), // degrees
  airTemperature: float("airTemperature").notNull(), // Celsius
  pressure: float("pressure").notNull(), // hPa
  humidity: float("humidity").notNull(), // percentage
  visibility: float("visibility").notNull(), // km
  conditions: varchar("conditions", { length: 100 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = typeof weatherData.$inferInsert;

/**
 * AI optimization recommendations
 */
export const optimizations = mysqlTable("optimizations", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").notNull().references(() => turbines.id),
  recommendationType: mysqlEnum("recommendationType", [
    "schedule",
    "maintenance",
    "efficiency",
    "safety"
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  titleAr: varchar("titleAr", { length: 255 }),
  description: text("description").notNull(),
  descriptionAr: text("descriptionAr"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  status: mysqlEnum("status", ["pending", "applied", "rejected", "expired"]).default("pending").notNull(),
  predictedImpact: float("predictedImpact").notNull(), // percentage improvement
  confidence: float("confidence").notNull(), // AI confidence score 0-1
  validFrom: timestamp("validFrom").notNull(),
  validUntil: timestamp("validUntil").notNull(),
  appliedAt: timestamp("appliedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Optimization = typeof optimizations.$inferSelect;
export type InsertOptimization = typeof optimizations.$inferInsert;

/**
 * Energy production forecasts
 */
export const forecasts = mysqlTable("forecasts", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").notNull().references(() => turbines.id),
  forecastDate: timestamp("forecastDate").notNull(),
  predictedPower: float("predictedPower").notNull(), // kW
  predictedEfficiency: float("predictedEfficiency").notNull(), // percentage
  confidence: float("confidence").notNull(), // 0-1
  weatherConditions: json("weatherConditions").$type<{
    windSpeed: number;
    waveHeight: number;
    temperature: number;
  }>().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Forecast = typeof forecasts.$inferSelect;
export type InsertForecast = typeof forecasts.$inferInsert;

/**
 * System alerts and notifications
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").references(() => turbines.id),
  alertType: mysqlEnum("alertType", [
    "maintenance",
    "failure",
    "efficiency",
    "anomaly",
    "optimal_window",
    "safety"
  ]).notNull(),
  severity: mysqlEnum("severity", ["info", "warning", "error", "critical"]).default("info").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  titleAr: varchar("titleAr", { length: 255 }),
  message: text("message").notNull(),
  messageAr: text("messageAr"),
  isRead: boolean("isRead").default(false).notNull(),
  isSent: boolean("isSent").default(false).notNull(),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

/**
 * Performance analytics and reports
 */
export const performanceReports = mysqlTable("performanceReports", {
  id: int("id").autoincrement().primaryKey(),
  turbineId: int("turbineId").references(() => turbines.id),
  reportType: mysqlEnum("reportType", ["daily", "weekly", "monthly", "annual"]).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  totalEnergyGenerated: float("totalEnergyGenerated").notNull(), // kWh
  averageEfficiency: float("averageEfficiency").notNull(), // percentage
  uptime: float("uptime").notNull(), // percentage
  downtime: float("downtime").notNull(), // hours
  wasteReduction: float("wasteReduction").notNull(), // percentage
  costSavings: float("costSavings").notNull(), // currency
  co2Offset: float("co2Offset").notNull(), // kg
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PerformanceReport = typeof performanceReports.$inferSelect;
export type InsertPerformanceReport = typeof performanceReports.$inferInsert;

/**
 * AI chat conversations
 */
export const chatSessions = mysqlTable("chatSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  title: varchar("title", { length: 255 }),
  language: mysqlEnum("language", ["en", "ar"]).default("en").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;

/**
 * AI chat messages
 */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull().references(() => chatSessions.id),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata").$type<{
    turbineId?: number;
    reportType?: string;
    queryType?: string;
  }>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
