CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int,
	`alertType` enum('maintenance','failure','efficiency','anomaly','optimal_window','safety') NOT NULL,
	`severity` enum('info','warning','error','critical') NOT NULL DEFAULT 'info',
	`title` varchar(255) NOT NULL,
	`titleAr` varchar(255),
	`message` text NOT NULL,
	`messageAr` text,
	`isRead` boolean NOT NULL DEFAULT false,
	`isSent` boolean NOT NULL DEFAULT false,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255),
	`language` enum('en','ar') NOT NULL DEFAULT 'en',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chatSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `energyData` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int NOT NULL,
	`powerOutput` float NOT NULL,
	`voltage` float NOT NULL,
	`current` float NOT NULL,
	`frequency` float NOT NULL,
	`efficiency` float NOT NULL,
	`temperature` float NOT NULL,
	`vibration` float NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `energyData_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `forecasts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int NOT NULL,
	`forecastDate` timestamp NOT NULL,
	`predictedPower` float NOT NULL,
	`predictedEfficiency` float NOT NULL,
	`confidence` float NOT NULL,
	`weatherConditions` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `forecasts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `optimizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int NOT NULL,
	`recommendationType` enum('schedule','maintenance','efficiency','safety') NOT NULL,
	`title` varchar(255) NOT NULL,
	`titleAr` varchar(255),
	`description` text NOT NULL,
	`descriptionAr` text,
	`priority` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`status` enum('pending','applied','rejected','expired') NOT NULL DEFAULT 'pending',
	`predictedImpact` float NOT NULL,
	`confidence` float NOT NULL,
	`validFrom` timestamp NOT NULL,
	`validUntil` timestamp NOT NULL,
	`appliedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `optimizations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performanceReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int,
	`reportType` enum('daily','weekly','monthly','annual') NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`totalEnergyGenerated` float NOT NULL,
	`averageEfficiency` float NOT NULL,
	`uptime` float NOT NULL,
	`downtime` float NOT NULL,
	`wasteReduction` float NOT NULL,
	`costSavings` float NOT NULL,
	`co2Offset` float NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `performanceReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `turbines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`nameAr` varchar(255),
	`serialNumber` varchar(100) NOT NULL,
	`status` enum('active','inactive','maintenance','error') NOT NULL DEFAULT 'active',
	`latitude` float NOT NULL,
	`longitude` float NOT NULL,
	`depth` float NOT NULL,
	`capacity` float NOT NULL,
	`efficiency` float NOT NULL DEFAULT 0,
	`rotationSpeed` float NOT NULL DEFAULT 0,
	`isOperating` boolean NOT NULL DEFAULT false,
	`lastMaintenanceDate` timestamp,
	`nextMaintenanceDate` timestamp,
	`installationDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `turbines_id` PRIMARY KEY(`id`),
	CONSTRAINT `turbines_serialNumber_unique` UNIQUE(`serialNumber`)
);
--> statement-breakpoint
CREATE TABLE `waveData` (
	`id` int AUTO_INCREMENT NOT NULL,
	`turbineId` int NOT NULL,
	`waveHeight` float NOT NULL,
	`waveAmplitude` float NOT NULL,
	`waveFrequency` float NOT NULL,
	`wavePeriod` float NOT NULL,
	`waveDirection` float NOT NULL,
	`currentSpeed` float NOT NULL,
	`currentDirection` float NOT NULL,
	`waterTemperature` float NOT NULL,
	`salinity` float NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `waveData_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weatherData` (
	`id` int AUTO_INCREMENT NOT NULL,
	`location` varchar(255) NOT NULL,
	`latitude` float NOT NULL,
	`longitude` float NOT NULL,
	`windSpeed` float NOT NULL,
	`windDirection` float NOT NULL,
	`airTemperature` float NOT NULL,
	`pressure` float NOT NULL,
	`humidity` float NOT NULL,
	`visibility` float NOT NULL,
	`conditions` varchar(100) NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weatherData_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `preferredLanguage` enum('en','ar') DEFAULT 'en' NOT NULL;--> statement-breakpoint
ALTER TABLE `alerts` ADD CONSTRAINT `alerts_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chatMessages` ADD CONSTRAINT `chatMessages_sessionId_chatSessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `chatSessions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chatSessions` ADD CONSTRAINT `chatSessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `energyData` ADD CONSTRAINT `energyData_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forecasts` ADD CONSTRAINT `forecasts_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `optimizations` ADD CONSTRAINT `optimizations_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `performanceReports` ADD CONSTRAINT `performanceReports_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `waveData` ADD CONSTRAINT `waveData_turbineId_turbines_id_fk` FOREIGN KEY (`turbineId`) REFERENCES `turbines`(`id`) ON DELETE no action ON UPDATE no action;