import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    setLanguage: protectedProcedure
      .input(z.object({ language: z.enum(["en", "ar"]) }))
      .mutation(async ({ ctx, input }) => {
        await db.updateUserLanguage(ctx.user.id, input.language);
        return { success: true };
      }),
  }),

  turbines: router({
    list: publicProcedure.query(async () => {
      return await db.getAllTurbines();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getTurbineById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        nameAr: z.string().optional(),
        serialNumber: z.string(),
        latitude: z.number(),
        longitude: z.number(),
        depth: z.number(),
        capacity: z.number(),
        installationDate: z.date(),
      }))
      .mutation(async ({ input }) => {
        return await db.createTurbine(input as any);
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["active", "inactive", "maintenance", "error"]),
        isOperating: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        await db.updateTurbineStatus(input.id, input.status, input.isOperating);
        
        // Create alert if status changed to error or maintenance
        if (input.status === "error" || input.status === "maintenance") {
          const turbine = await db.getTurbineById(input.id);
          await db.createAlert({
            turbineId: input.id,
            alertType: input.status === "error" ? "failure" : "maintenance",
            severity: input.status === "error" ? "critical" : "warning",
            title: input.status === "error" 
              ? `Turbine ${turbine?.name} Error` 
              : `Turbine ${turbine?.name} Maintenance`,
            titleAr: input.status === "error"
              ? `خطأ في التوربين ${turbine?.nameAr || turbine?.name}`
              : `صيانة التوربين ${turbine?.nameAr || turbine?.name}`,
            message: input.status === "error"
              ? "Turbine has encountered an error and stopped operation."
              : "Turbine has been placed in maintenance mode.",
            messageAr: input.status === "error"
              ? "واجه التوربين خطأ وتوقف عن العمل."
              : "تم وضع التوربين في وضع الصيانة.",
            isRead: false,
            isSent: false,
          });
        }
        
        return { success: true };
      }),
  }),

  energy: router({
    latest: publicProcedure
      .input(z.object({ turbineId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLatestEnergyData(input.turbineId);
      }),
    
    range: publicProcedure
      .input(z.object({
        turbineId: z.number(),
        startDate: z.date(),
        endDate: z.date(),
      }))
      .query(async ({ input }) => {
        return await db.getEnergyDataRange(input.turbineId, input.startDate, input.endDate);
      }),
    
    totalOutput: publicProcedure.query(async () => {
      return await db.getTotalEnergyOutput();
    }),
  }),

  waves: router({
    latest: publicProcedure
      .input(z.object({ turbineId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLatestWaveData(input.turbineId);
      }),
    
    range: publicProcedure
      .input(z.object({
        turbineId: z.number(),
        startDate: z.date(),
        endDate: z.date(),
      }))
      .query(async ({ input }) => {
        return await db.getWaveDataRange(input.turbineId, input.startDate, input.endDate);
      }),
  }),

  weather: router({
    latest: publicProcedure
      .input(z.object({ location: z.string() }))
      .query(async ({ input }) => {
        return await db.getLatestWeatherData(input.location);
      }),
  }),

  optimizations: router({
    active: publicProcedure
      .input(z.object({ turbineId: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.getActiveOptimizations(input.turbineId);
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "applied", "rejected", "expired"]),
      }))
      .mutation(async ({ input }) => {
        await db.updateOptimizationStatus(input.id, input.status);
        return { success: true };
      }),
    
    generate: protectedProcedure
      .input(z.object({ turbineId: z.number() }))
      .mutation(async ({ input }) => {
        // Get turbine data
        const turbine = await db.getTurbineById(input.turbineId);
        if (!turbine) throw new Error("Turbine not found");
        
        // Get recent energy and wave data
        const energyData = await db.getLatestEnergyData(input.turbineId);
        const waveData = await db.getLatestWaveData(input.turbineId);
        
        // Use AI to generate optimization recommendation
        const prompt = `Analyze the following turbine data and provide an optimization recommendation:
        
Turbine: ${turbine.name}
Current Status: ${turbine.status}
Current Efficiency: ${turbine.efficiency}%
Current Power Output: ${energyData?.powerOutput || 0} kW
Wave Height: ${waveData?.waveHeight || 0} m
Wave Frequency: ${waveData?.waveFrequency || 0} Hz
Current Speed: ${waveData?.currentSpeed || 0} m/s

Provide a JSON response with:
- recommendationType: "schedule" | "maintenance" | "efficiency" | "safety"
- title: Brief title for the recommendation
- description: Detailed explanation
- priority: "low" | "medium" | "high" | "critical"
- predictedImpact: Percentage improvement (positive or negative)
- confidence: Confidence score 0-1
- validHours: How many hours this recommendation is valid`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are an AI optimization expert for marine wave energy systems. Provide practical, data-driven recommendations." },
            { role: "user", content: prompt }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "optimization_recommendation",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  recommendationType: { type: "string", enum: ["schedule", "maintenance", "efficiency", "safety"] },
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string", enum: ["low", "medium", "high", "critical"] },
                  predictedImpact: { type: "number" },
                  confidence: { type: "number" },
                  validHours: { type: "number" },
                },
                required: ["recommendationType", "title", "description", "priority", "predictedImpact", "confidence", "validHours"],
                additionalProperties: false,
              },
            },
          },
        });

        const content = typeof response.choices[0].message.content === 'string'
          ? response.choices[0].message.content
          : JSON.stringify(response.choices[0].message.content);
        const recommendation = JSON.parse(content);
        
        const now = new Date();
        const validUntil = new Date(now.getTime() + recommendation.validHours * 60 * 60 * 1000);
        
        await db.createOptimization({
          turbineId: input.turbineId,
          recommendationType: recommendation.recommendationType,
          title: recommendation.title,
          description: recommendation.description,
          priority: recommendation.priority,
          status: "pending",
          predictedImpact: recommendation.predictedImpact,
          confidence: recommendation.confidence,
          validFrom: now,
          validUntil,
        });
        
        return { success: true, recommendation };
      }),
  }),

  forecasts: router({
    upcoming: publicProcedure
      .input(z.object({ 
        turbineId: z.number(),
        days: z.number().default(7),
      }))
      .query(async ({ input }) => {
        return await db.getUpcomingForecasts(input.turbineId, input.days);
      }),
  }),

  alerts: router({
    unread: publicProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return await db.getUnreadAlerts(input.limit);
      }),
    
    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markAlertAsRead(input.id);
        return { success: true };
      }),
  }),

  reports: router({
    list: publicProcedure
      .input(z.object({
        turbineId: z.number().optional(),
        reportType: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getPerformanceReports(input.turbineId, input.reportType);
      }),
  }),

  chat: router({
    sessions: protectedProcedure.query(async ({ ctx }) => {
      return await db.getChatSessions(ctx.user.id);
    }),
    
    messages: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await db.getChatMessages(input.sessionId);
      }),
    
    createSession: protectedProcedure
      .input(z.object({ language: z.enum(["en", "ar"]).default("en") }))
      .mutation(async ({ ctx, input }) => {
        return await db.createChatSession(ctx.user.id, input.language);
      }),
    
    sendMessage: protectedProcedure
      .input(z.object({
        sessionId: z.number(),
        message: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        await db.insertChatMessage({
          sessionId: input.sessionId,
          role: "user",
          content: input.message,
        });
        
        // Get session info
        const messages = await db.getChatMessages(input.sessionId);
        const session = (await db.getChatSessions(ctx.user.id)).find(s => s.id === input.sessionId);
        
        // Get context data
        const turbines = await db.getAllTurbines();
        const alerts = await db.getUnreadAlerts(5);
        
        const systemPrompt = session?.language === "ar" 
          ? "أنت مساعد ذكي متخصص في أنظمة طاقة الأمواج البحرية. ساعد المستخدم في فهم بيانات الطاقة، والتوربينات، والتحسينات. أجب باللغة العربية."
          : "You are an AI assistant specialized in marine wave energy systems. Help users understand energy data, turbines, and optimizations. Answer in English.";
        
        const contextInfo = `
Available Turbines: ${turbines.map(t => `${t.name} (Status: ${t.status}, Efficiency: ${t.efficiency}%)`).join(", ")}
Recent Alerts: ${alerts.map(a => a.title).join(", ")}
`;
        
        // Generate AI response
        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt + "\n\nContext:\n" + contextInfo },
            ...messages.slice(-10).map(m => ({
              role: m.role as "user" | "assistant",
              content: m.content as string,
            })),
          ],
        });
        
        const assistantMessage = typeof response.choices[0].message.content === 'string' 
          ? response.choices[0].message.content 
          : JSON.stringify(response.choices[0].message.content);
        
        // Save assistant message
        await db.insertChatMessage({
          sessionId: input.sessionId,
          role: "assistant",
          content: assistantMessage,
        });
        
        // Update session title if it's the first exchange
        if (messages.length === 1) {
          const title = input.message.slice(0, 50) + (input.message.length > 50 ? "..." : "");
          await db.updateChatSessionTitle(input.sessionId, title);
        }
        
        return { message: assistantMessage };
      }),
  }),
});

export type AppRouter = typeof appRouter;
