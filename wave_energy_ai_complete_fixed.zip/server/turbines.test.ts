import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    preferredLanguage: "en",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("turbines router", () => {
  it("should list all turbines", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const turbines = await caller.turbines.list();

    expect(Array.isArray(turbines)).toBe(true);
    expect(turbines.length).toBeGreaterThan(0);
    
    if (turbines.length > 0) {
      const turbine = turbines[0];
      expect(turbine).toHaveProperty("id");
      expect(turbine).toHaveProperty("name");
      expect(turbine).toHaveProperty("status");
      expect(turbine).toHaveProperty("efficiency");
    }
  });

  it("should get turbine by id", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const turbines = await caller.turbines.list();
    if (turbines.length === 0) {
      return; // Skip if no turbines
    }

    const firstTurbine = turbines[0];
    const turbine = await caller.turbines.getById({ id: firstTurbine.id });

    expect(turbine).toBeDefined();
    expect(turbine?.id).toBe(firstTurbine.id);
    expect(turbine?.name).toBe(firstTurbine.name);
  });

  it("should update turbine status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const turbines = await caller.turbines.list();
    if (turbines.length === 0) {
      return; // Skip if no turbines
    }

    const firstTurbine = turbines[0];
    
    const result = await caller.turbines.updateStatus({
      id: firstTurbine.id,
      status: "maintenance",
      isOperating: false,
    });

    expect(result).toEqual({ success: true });

    // Verify the update
    const updated = await caller.turbines.getById({ id: firstTurbine.id });
    expect(updated?.status).toBe("maintenance");
    expect(updated?.isOperating).toBe(false);
  });
});

describe("energy data router", () => {
  it("should get latest energy data for turbine", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const turbines = await caller.turbines.list();
    if (turbines.length === 0) {
      return; // Skip if no turbines
    }

    const energy = await caller.energy.latest({ turbineId: turbines[0].id });

    if (energy) {
      expect(energy).toHaveProperty("powerOutput");
      expect(energy).toHaveProperty("efficiency");
      expect(energy).toHaveProperty("temperature");
      expect(typeof energy.powerOutput).toBe("number");
    }
  });

  it("should get total energy output", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const total = await caller.energy.totalOutput();

    expect(typeof total).toBe("number");
    expect(total).toBeGreaterThanOrEqual(0);
  });
});

describe("optimizations router", () => {
  it("should get active optimizations", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const optimizations = await caller.optimizations.active({});

    expect(Array.isArray(optimizations)).toBe(true);
    
    if (optimizations.length > 0) {
      const opt = optimizations[0];
      expect(opt).toHaveProperty("title");
      expect(opt).toHaveProperty("description");
      expect(opt).toHaveProperty("predictedImpact");
      expect(opt).toHaveProperty("confidence");
      expect(opt.status).toBe("pending");
    }
  });

  it("should update optimization status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const optimizations = await caller.optimizations.active({});
    if (optimizations.length === 0) {
      return; // Skip if no optimizations
    }

    const result = await caller.optimizations.updateStatus({
      id: optimizations[0].id,
      status: "applied",
    });

    expect(result).toEqual({ success: true });
  });
});

describe("alerts router", () => {
  it("should get unread alerts", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const alerts = await caller.alerts.unread({ limit: 10 });

    expect(Array.isArray(alerts)).toBe(true);
    
    if (alerts.length > 0) {
      const alert = alerts[0];
      expect(alert).toHaveProperty("title");
      expect(alert).toHaveProperty("message");
      expect(alert).toHaveProperty("severity");
      expect(alert.isRead).toBe(false);
    }
  });

  it("should mark alert as read", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const alerts = await caller.alerts.unread({ limit: 1 });
    if (alerts.length === 0) {
      return; // Skip if no alerts
    }

    const result = await caller.alerts.markAsRead({ id: alerts[0].id });

    expect(result).toEqual({ success: true });
  });
});
