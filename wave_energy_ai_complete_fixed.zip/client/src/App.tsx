import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import Navigation from "./components/Navigation";
import Dashboard from "./pages/Dashboard";
import AIAssistant from "./pages/AIAssistant";
import TurbineControl from "./pages/TurbineControl";
import Optimizations from "./pages/Optimizations";
import Simulation from "./pages/Simulation";

function Router() {
  return (
    <>
      <Navigation />
      <Switch>
        <Route path={"/"} component={Dashboard} />
        <Route path={"/turbines"} component={TurbineControl} />
        <Route path={"/optimizations"} component={Optimizations} />
        <Route path={"/ai-assistant"} component={AIAssistant} />
        <Route path={"/simulation"} component={Simulation} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <LanguageProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
