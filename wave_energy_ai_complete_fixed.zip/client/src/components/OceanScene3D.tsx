import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, PerspectiveCamera } from "@react-three/drei";
import { useRef, useState, useMemo, useEffect } from "react";
import * as THREE from "three";
import { Button } from "@/components/ui/button";
import { Play, Pause, Settings, Info, TrendingUp, GraduationCap, Video, Save, FileText } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
// Recording uses Canvas API directly, no need for html2canvas

interface Turbine {
  id: number;
  name: string;
  nameAr?: string | null;
  latitude: number;
  longitude: number;
  status: "active" | "inactive" | "maintenance" | "error";
  efficiency: number;
  rotationSpeed: number;
  isOperating: boolean;
}

interface OceanScene3DProps {
  turbines: Turbine[];
  selectedTurbineId?: number;
  onTurbineSelect?: (id: number) => void;
}

type ComponentType = "buoy" | "arm" | "generator" | "base" | null;

interface Scenario {
  id: string;
  name: string;
  waveIntensity: number;
  timestamp: number;
  analysis: {
    powerOutput: string;
    efficiency: string;
    waveEnergy: string;
    mechanicalLoss: string;
  };
}

// Tutorial steps
const tutorialSteps = {
  ar: [
    {
      title: "مرحباً بك في منصة طاقة الأمواج!",
      description: "سأرشدك خطوة بخطوة لاستكشاف جميع الميزات المتقدمة للمنصة.",
      target: null,
      position: "center"
    },
    {
      title: "التصور ثلاثي الأبعاد",
      description: "هذا هو التوربين البحري. يمكنك سحب الماوس للدوران والتكبير/التصغير بعجلة الماوس.",
      target: "canvas",
      position: "bottom"
    },
    {
      title: "انقر على المكونات",
      description: "انقر على أي جزء من التوربين (العوامة، الذراع، المولد، القاعدة) لعرض شرح تفصيلي ومواصفات تقنية.",
      target: "canvas",
      position: "bottom"
    },
    {
      title: "التحكم بالمحاكاة",
      description: "استخدم هذا الزر لإيقاف أو تشغيل المحاكاة مؤقتاً.",
      target: "play-button",
      position: "top"
    },
    {
      title: "إعدادات المحاكاة",
      description: "اضغط هنا لفتح لوحة التحكم وتعديل شدة الأمواج وسرعتها.",
      target: "settings-button",
      position: "top"
    },
    {
      title: "تحليل الأداء",
      description: "عند اختيار توربين، ستظهر لوحة تحليل الأداء المباشر مع جميع المقاييس.",
      target: "analysis-panel",
      position: "left"
    },
    {
      title: "تسجيل المحاكاة",
      description: "يمكنك تسجيل فيديو قصير من المحاكاة وتحميله أو مشاركته.",
      target: "record-button",
      position: "top"
    },
    {
      title: "حفظ السيناريوهات",
      description: "احفظ إعدادات المحاكاة الحالية كسيناريو لمقارنتها لاحقاً.",
      target: "save-button",
      position: "top"
    },
    {
      title: "مقارنة السيناريوهات",
      description: "اعرض جدول مقارنة لجميع السيناريوهات المحفوظة وحلل الفروقات.",
      target: "compare-button",
      position: "top"
    },
    {
      title: "جاهز للبدء!",
      description: "الآن أنت جاهز لاستكشاف المنصة بنفسك. استمتع!",
      target: null,
      position: "center"
    }
  ],
  en: [
    {
      title: "Welcome to Wave Energy Platform!",
      description: "I'll guide you step by step through all advanced features.",
      target: null,
      position: "center"
    },
    {
      title: "3D Visualization",
      description: "This is the marine turbine. Drag to rotate and scroll to zoom.",
      target: "canvas",
      position: "bottom"
    },
    {
      title: "Click Components",
      description: "Click any turbine part (buoy, arm, generator, base) to view detailed explanation and specs.",
      target: "canvas",
      position: "bottom"
    },
    {
      title: "Simulation Control",
      description: "Use this button to pause or resume the simulation.",
      target: "play-button",
      position: "top"
    },
    {
      title: "Simulation Settings",
      description: "Click here to open control panel and adjust wave intensity and speed.",
      target: "settings-button",
      position: "top"
    },
    {
      title: "Performance Analysis",
      description: "When selecting a turbine, real-time performance analysis panel appears with all metrics.",
      target: "analysis-panel",
      position: "left"
    },
    {
      title: "Record Simulation",
      description: "You can record a short video of the simulation and download or share it.",
      target: "record-button",
      position: "top"
    },
    {
      title: "Save Scenarios",
      description: "Save current simulation settings as a scenario for later comparison.",
      target: "save-button",
      position: "top"
    },
    {
      title: "Compare Scenarios",
      description: "View comparison table of all saved scenarios and analyze differences.",
      target: "compare-button",
      position: "top"
    },
    {
      title: "Ready to Start!",
      description: "Now you're ready to explore the platform yourself. Enjoy!",
      target: null,
      position: "center"
    }
  ]
};

// Component explanations
const componentExplanations = {
  ar: {
    buoy: {
      title: "العوامة الطافية",
      description: "تطفو على سطح الماء وتتحرك صعوداً وهبوطاً مع حركة الأمواج. مصنوعة من مواد مقاومة للتآكل وتحتوي على لوحة شمسية صغيرة للطاقة الاحتياطية.",
      specs: ["القطر: 1.8 متر", "الوزن: 450 كجم", "المادة: فولاذ مقاوم للصدأ"]
    },
    arm: {
      title: "الذراع الميكانيكي",
      description: "يربط العوامة بالمولد ويحول الحركة الرأسية للأمواج إلى حركة دورانية. يحتوي على أنابيب هيدروليكية مزدوجة لزيادة الكفاءة.",
      specs: ["الطول: 2.5 متر", "نطاق الحركة: ±45°", "القوة القصوى: 5000 نيوتن"]
    },
    generator: {
      title: "المولد الكهربائي",
      description: "يحول الطاقة الميكانيكية إلى طاقة كهربائية. يحتوي على ملفات نحاسية دوارة وزعانف تبريد لمنع ارتفاع الحرارة.",
      specs: ["القدرة: 2500 كيلووات", "الجهد: 690 فولت", "الكفاءة: 92%"]
    },
    base: {
      title: "القاعدة الثابتة",
      description: "مثبتة في قاع البحر بثلاثة أعمدة فولاذية. توفر الاستقرار للنظام بأكمله وتحتوي على كابلات الطاقة.",
      specs: ["العمق: 15-30 متر", "الوزن: 12 طن", "عدد الأعمدة: 3"]
    }
  },
  en: {
    buoy: {
      title: "Floating Buoy",
      description: "Floats on water surface and moves up and down with wave motion. Made of corrosion-resistant materials with a small solar panel for backup power.",
      specs: ["Diameter: 1.8m", "Weight: 450kg", "Material: Stainless Steel"]
    },
    arm: {
      title: "Mechanical Arm",
      description: "Connects buoy to generator and converts vertical wave motion to rotational movement. Contains dual hydraulic pistons for increased efficiency.",
      specs: ["Length: 2.5m", "Range: ±45°", "Max Force: 5000N"]
    },
    generator: {
      title: "Electric Generator",
      description: "Converts mechanical energy to electrical energy. Contains rotating copper coils and cooling fins to prevent overheating.",
      specs: ["Capacity: 2500kW", "Voltage: 690V", "Efficiency: 92%"]
    },
    base: {
      title: "Fixed Base",
      description: "Anchored to seabed with three steel columns. Provides stability for entire system and contains power cables.",
      specs: ["Depth: 15-30m", "Weight: 12 tons", "Columns: 3"]
    }
  }
};

// Wave Energy Turbine Component
function WaveEnergyTurbine({ 
  turbine, 
  position, 
  isSelected, 
  onClick,
  simulationActive,
  waveIntensity,
  onComponentClick
}: { 
  turbine: Turbine; 
  position: [number, number, number]; 
  isSelected: boolean;
  onClick: () => void;
  simulationActive: boolean;
  waveIntensity: number;
  onComponentClick: (component: ComponentType) => void;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const buoyRef = useRef<THREE.Mesh>(null);
  const armRef = useRef<THREE.Group>(null);
  const rotorRef = useRef<THREE.Mesh>(null);
  const [hoveredComponent, setHoveredComponent] = useState<ComponentType>(null);
  
  const statusColors = {
    active: "#10b981",
    inactive: "#6b7280",
    maintenance: "#f59e0b",
    error: "#ef4444",
  };
  
  useFrame(({ clock }) => {
    if (!simulationActive) return;
    
    const time = clock.getElapsedTime();
    const wavePhase = time * (1 + waveIntensity * 0.5);
    const amplitude = 0.3 * waveIntensity;
    
    if (buoyRef.current) {
      buoyRef.current.position.y = Math.sin(wavePhase) * amplitude;
      buoyRef.current.rotation.x = Math.sin(wavePhase * 0.8) * 0.1 * waveIntensity;
      buoyRef.current.rotation.z = Math.cos(wavePhase * 0.6) * 0.1 * waveIntensity;
    }
    
    if (armRef.current) {
      armRef.current.rotation.x = Math.sin(wavePhase) * 0.4 * waveIntensity - 0.2;
    }
    
    if (rotorRef.current && turbine.status === "active") {
      rotorRef.current.rotation.z += turbine.rotationSpeed * 0.002 * waveIntensity;
    }
  });
  
  const getEmissive = (component: ComponentType) => {
    if (hoveredComponent === component) return 0.3;
    if (isSelected) return 0.2;
    return 0;
  };
  
  return (
    <group ref={groupRef} position={position} onClick={onClick}>
      {/* Fixed Base */}
      <group 
        position={[0, -2.5, 0]}
        onPointerOver={() => setHoveredComponent("base")}
        onPointerOut={() => setHoveredComponent(null)}
        onClick={(e) => { e.stopPropagation(); onComponentClick("base"); }}
      >
        <mesh position={[0, 0, 0]} castShadow>
          <cylinderGeometry args={[1.5, 1.8, 0.6, 8]} />
          <meshStandardMaterial 
            color="#2c3e50" 
            metalness={0.9} 
            roughness={0.2}
            emissive="#2c3e50"
            emissiveIntensity={getEmissive("base")}
          />
        </mesh>
        
        {[0, 120, 240].map((angle, i) => {
          const rad = (angle * Math.PI) / 180;
          return (
            <mesh 
              key={i}
              position={[Math.cos(rad) * 1, 1.2, Math.sin(rad) * 1]}
              castShadow
            >
              <cylinderGeometry args={[0.12, 0.15, 2.4, 12]} />
              <meshStandardMaterial 
                color="#34495e" 
                metalness={0.8} 
                roughness={0.3}
                emissive="#34495e"
                emissiveIntensity={getEmissive("base")}
              />
            </mesh>
          );
        })}
      </group>
      
      {/* Floating Buoy */}
      <group
        onPointerOver={() => setHoveredComponent("buoy")}
        onPointerOut={() => setHoveredComponent(null)}
        onClick={(e) => { e.stopPropagation(); onComponentClick("buoy"); }}
      >
        <mesh ref={buoyRef} position={[0, 0.6, 0]} castShadow>
          <sphereGeometry args={[0.9, 32, 32, 0, Math.PI * 2, 0, Math.PI * 0.65]} />
          <meshStandardMaterial 
            color="#ff6b35" 
            metalness={0.4} 
            roughness={0.5}
            emissive="#ff6b35"
            emissiveIntensity={getEmissive("buoy")}
          />
        </mesh>
        
        <mesh position={[0, 1.1, 0]} castShadow>
          <cylinderGeometry args={[0.6, 0.7, 0.25, 16]} />
          <meshStandardMaterial 
            color="#e74c3c" 
            metalness={0.6} 
            roughness={0.3}
          />
        </mesh>
        
        {[0.3, 0, -0.3].map((yPos, i) => (
          <mesh key={i} position={[0, yPos, 0]}>
            <torusGeometry args={[0.92, 0.05, 8, 24]} />
            <meshStandardMaterial 
              color="#c0392b" 
              metalness={0.5} 
              roughness={0.5}
            />
          </mesh>
        ))}
      </group>
      
      {/* Mechanical Arm */}
      <group 
        ref={armRef} 
        position={[0, 0.2, 0]}
        onPointerOver={() => setHoveredComponent("arm")}
        onPointerOut={() => setHoveredComponent(null)}
        onClick={(e) => { e.stopPropagation(); onComponentClick("arm"); }}
      >
        <mesh position={[0, -0.7, 0]} castShadow>
          <cylinderGeometry args={[0.1, 0.1, 1.8, 12]} />
          <meshStandardMaterial 
            color="#95a5a6" 
            metalness={0.85} 
            roughness={0.15}
            emissive="#95a5a6"
            emissiveIntensity={getEmissive("arm")}
          />
        </mesh>
        
        {[-0.15, 0.15].map((offset, i) => (
          <mesh key={i} position={[offset, -0.7, 0]} castShadow>
            <cylinderGeometry args={[0.04, 0.04, 1.6, 8]} />
            <meshStandardMaterial 
              color="#7f8c8d" 
              metalness={0.9} 
              roughness={0.1}
            />
          </mesh>
        ))}
        
        <mesh position={[0, -1.5, 0]} castShadow>
          <sphereGeometry args={[0.18, 16, 16]} />
          <meshStandardMaterial 
            color="#7f8c8d" 
            metalness={0.95} 
            roughness={0.05}
          />
        </mesh>
        
        <mesh position={[0, -2.1, 0]} castShadow>
          <cylinderGeometry args={[0.12, 0.12, 1.2, 12]} />
          <meshStandardMaterial 
            color="#95a5a6" 
            metalness={0.85} 
            roughness={0.15}
          />
        </mesh>
      </group>
      
      {/* Electric Generator */}
      <group 
        position={[0, -3, 0]}
        onPointerOver={() => setHoveredComponent("generator")}
        onPointerOut={() => setHoveredComponent(null)}
        onClick={(e) => { e.stopPropagation(); onComponentClick("generator"); }}
      >
        <mesh castShadow>
          <boxGeometry args={[1.2, 1, 1.2]} />
          <meshStandardMaterial 
            color="#3498db" 
            metalness={0.7} 
            roughness={0.3}
            emissive="#3498db"
            emissiveIntensity={getEmissive("generator")}
          />
        </mesh>
        
        <mesh ref={rotorRef} position={[0, 0, 0]} castShadow>
          <cylinderGeometry args={[0.35, 0.35, 1.1, 16]} />
          <meshStandardMaterial 
            color={statusColors[turbine.status]}
            metalness={0.95} 
            roughness={0.05}
            emissive={statusColors[turbine.status]}
            emissiveIntensity={turbine.status === "active" ? 0.6 : 0.1}
          />
        </mesh>
        
        {[0, 90, 180, 270].map((angle, i) => {
          const rad = (angle * Math.PI) / 180;
          return (
            <mesh 
              key={i}
              position={[Math.cos(rad) * 0.6, 0, Math.sin(rad) * 0.6]}
              rotation={[0, rad, 0]}
              castShadow
            >
              <boxGeometry args={[0.06, 0.8, 0.35]} />
              <meshStandardMaterial 
                color="#2980b9" 
                metalness={0.75} 
                roughness={0.25}
              />
            </mesh>
          );
        })}
      </group>
      
      {/* Status light */}
      <mesh position={[0, 1.5, 0]} castShadow>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial 
          color={statusColors[turbine.status]}
          emissive={statusColors[turbine.status]}
          emissiveIntensity={1.2}
        />
      </mesh>
      
      {turbine.status === "active" && (
        <pointLight 
          position={[0, 0, 0]} 
          color={statusColors[turbine.status]}
          intensity={0.8}
          distance={4}
        />
      )}
      
      {isSelected && (
        <mesh position={[0, -1.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[2, 2.3, 32]} />
          <meshBasicMaterial 
            color="#3498db" 
            transparent 
            opacity={0.6}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}
    </group>
  );
}

// Ocean Surface
function OceanSurface({ simulationActive, waveIntensity }: { simulationActive: boolean; waveIntensity: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  const geometry = useMemo(() => {
    return new THREE.PlaneGeometry(60, 60, 120, 120);
  }, []);
  
  useFrame(({ clock }) => {
    if (!meshRef.current || !simulationActive) return;
    
    const time = clock.getElapsedTime();
    const positions = geometry.attributes.position;
    
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      
      const wave1 = Math.sin(x * 0.25 + time * 1.5) * 0.35 * waveIntensity;
      const wave2 = Math.sin(y * 0.18 + time * 1.3) * 0.25 * waveIntensity;
      const wave3 = Math.sin((x + y) * 0.12 + time * 1.1) * 0.18 * waveIntensity;
      
      positions.setZ(i, wave1 + wave2 + wave3);
    }
    
    positions.needsUpdate = true;
    geometry.computeVertexNormals();
  });
  
  return (
    <mesh 
      ref={meshRef} 
      geometry={geometry}
      rotation={[-Math.PI / 2, 0, 0]} 
      position={[0, -0.8, 0]}
      receiveShadow
    >
      <meshStandardMaterial 
        color="#006994"
        transparent
        opacity={0.75}
        metalness={0.9}
        roughness={0.15}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

// Scene
function Scene({ 
  turbines, 
  selectedTurbineId, 
  onTurbineSelect,
  simulationActive,
  waveIntensity,
  onComponentClick
}: OceanScene3DProps & { 
  simulationActive: boolean; 
  waveIntensity: number;
  onComponentClick: (component: ComponentType) => void;
}) {
  return (
    <>
      <PerspectiveCamera makeDefault position={[18, 10, 18]} />
      <OrbitControls 
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        minDistance={8}
        maxDistance={45}
        maxPolarAngle={Math.PI / 2.1}
      />
      
      <ambientLight intensity={0.5} />
      <directionalLight 
        position={[15, 15, 8]} 
        intensity={1.2}
        castShadow
      />
      <hemisphereLight 
        color="#87CEEB" 
        groundColor="#006994" 
        intensity={0.6}
      />
      
      <OceanSurface simulationActive={simulationActive} waveIntensity={waveIntensity} />
      
      {turbines.map((turbine, index) => {
        const angle = (index / turbines.length) * Math.PI * 2;
        const radius = 10;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        
        return (
          <WaveEnergyTurbine
            key={turbine.id}
            turbine={turbine}
            position={[x, 0, z]}
            isSelected={turbine.id === selectedTurbineId}
            onClick={() => onTurbineSelect?.(turbine.id)}
            simulationActive={simulationActive}
            waveIntensity={waveIntensity}
            onComponentClick={onComponentClick}
          />
        );
      })}
      
      <gridHelper args={[60, 60, "#1e3a5f", "#1e3a5f"]} position={[0, -4, 0]} />
    </>
  );
}

// Main Component
export default function OceanScene3D(props: OceanScene3DProps) {
  const [simulationActive, setSimulationActive] = useState(true);
  const [showControls, setShowControls] = useState(false);
  const [waveIntensity, setWaveIntensity] = useState(1);
  const [selectedComponent, setSelectedComponent] = useState<ComponentType>(null);
  const [tutorialActive, setTutorialActive] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingFrames, setRecordingFrames] = useState<string[]>([]);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  const { t, language } = useLanguage();
  
  const selectedTurbine = props.turbines.find(t => t.id === props.selectedTurbineId);
  const explanations = language === "ar" ? componentExplanations.ar : componentExplanations.en;
  const steps = language === "ar" ? tutorialSteps.ar : tutorialSteps.en;
  
  // Calculate analysis
  const analysis = selectedTurbine ? {
    powerOutput: (selectedTurbine.efficiency * waveIntensity * 25).toFixed(1),
    efficiency: (selectedTurbine.efficiency * (0.8 + waveIntensity * 0.2)).toFixed(1),
    waveEnergy: (waveIntensity * 100).toFixed(0),
    mechanicalLoss: ((1 - selectedTurbine.efficiency / 100) * 100).toFixed(1)
  } : null;
  
  // Tutorial navigation
  const nextTutorialStep = () => {
    if (tutorialStep < steps.length - 1) {
      setTutorialStep(tutorialStep + 1);
    } else {
      setTutorialActive(false);
      setTutorialStep(0);
      toast.success(language === "ar" ? "انتهت الجولة الإرشادية!" : "Tutorial completed!");
    }
  };
  
  const skipTutorial = () => {
    setTutorialActive(false);
    setTutorialStep(0);
  };
  
  // Recording functionality
  const startRecording = async () => {
    setIsRecording(true);
    setRecordingFrames([]);
    toast.info(language === "ar" ? "بدأ التسجيل..." : "Recording started...");
    
    const frames: string[] = [];
    const duration = 10000; // 10 seconds
    const fps = 10; // 10 frames per second
    const interval = 1000 / fps;
    const totalFrames = (duration / 1000) * fps;
    
    // Find the actual Three.js canvas element
    const threeCanvas = canvasRef.current?.querySelector('canvas');
    
    if (!threeCanvas) {
      toast.error(language === "ar" ? "خطأ في التسجيل" : "Recording error");
      setIsRecording(false);
      return;
    }
    
    for (let i = 0; i < totalFrames; i++) {
      await new Promise(resolve => setTimeout(resolve, interval));
      
      try {
        // Directly capture the Three.js canvas
        frames.push(threeCanvas.toDataURL('image/jpeg', 0.8));
      } catch (error) {
        console.error('Frame capture error:', error);
      }
    }
    
    setRecordingFrames(frames);
    setIsRecording(false);
    toast.success(language === "ar" ? "اكتمل التسجيل!" : "Recording completed!");
    downloadRecording(frames);
  };
  
  const downloadRecording = (frames: string[]) => {
    // Create a simple slideshow HTML
    const html = `
<!DOCTYPE html>
<html>
<head>
  <title>Wave Energy Simulation Recording</title>
  <style>
    body { margin: 0; background: #000; display: flex; justify-content: center; align-items: center; height: 100vh; }
    img { max-width: 100%; max-height: 100vh; }
  </style>
</head>
<body>
  <img id="frame" />
  <script>
    const frames = ${JSON.stringify(frames)};
    let index = 0;
    const img = document.getElementById('frame');
    function nextFrame() {
      img.src = frames[index];
      index = (index + 1) % frames.length;
    }
    setInterval(nextFrame, 100);
    nextFrame();
  </script>
</body>
</html>`;
    
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wave-simulation-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  // Scenario management
  const saveScenario = () => {
    if (!selectedTurbine || !analysis) {
      toast.error(language === "ar" ? "اختر توربيناً أولاً" : "Select a turbine first");
      return;
    }
    
    const scenario: Scenario = {
      id: Date.now().toString(),
      name: `${language === "ar" ? "سيناريو" : "Scenario"} ${scenarios.length + 1}`,
      waveIntensity,
      timestamp: Date.now(),
      analysis
    };
    
    setScenarios([...scenarios, scenario]);
    toast.success(language === "ar" ? "تم حفظ السيناريو!" : "Scenario saved!");
  };
  
  const loadScenario = (scenario: Scenario) => {
    setWaveIntensity(scenario.waveIntensity);
    toast.success(language === "ar" ? "تم تحميل السيناريو!" : "Scenario loaded!");
  };
  
  const deleteScenario = (id: string) => {
    setScenarios(scenarios.filter(s => s.id !== id));
    toast.success(language === "ar" ? "تم حذف السيناريو!" : "Scenario deleted!");
  };
  
  return (
    <div ref={canvasRef} className="relative w-full h-full">
      <Canvas shadows gl={{ antialias: true }}>
        <Scene 
          {...props} 
          simulationActive={simulationActive} 
          waveIntensity={waveIntensity}
          onComponentClick={setSelectedComponent}
        />
      </Canvas>
      
      {/* Control Buttons */}
      <div className="absolute bottom-4 left-4 z-10 flex gap-2 flex-wrap">
        <Button
          id="play-button"
          onClick={() => setSimulationActive(!simulationActive)}
          className="gap-2 shadow-lg"
          variant={simulationActive ? "default" : "secondary"}
          size="lg"
        >
          {simulationActive ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          <span className="font-semibold">
            {simulationActive 
              ? (language === "ar" ? "إيقاف" : "Pause")
              : (language === "ar" ? "تشغيل" : "Start")}
          </span>
        </Button>
        
        <Button
          id="settings-button"
          onClick={() => setShowControls(!showControls)}
          className="gap-2 shadow-lg"
          variant={showControls ? "default" : "outline"}
          size="lg"
        >
          <Settings className="h-5 w-5" />
        </Button>
        
        <Button
          id="tutorial-button"
          onClick={() => { setTutorialActive(true); setTutorialStep(0); }}
          className="gap-2 shadow-lg"
          variant="outline"
          size="lg"
        >
          <GraduationCap className="h-5 w-5" />
        </Button>
        
        <Button
          id="record-button"
          onClick={startRecording}
          className="gap-2 shadow-lg"
          variant="outline"
          size="lg"
          disabled={isRecording}
        >
          <Video className="h-5 w-5" />
          {isRecording && <span className="animate-pulse">●</span>}
        </Button>
        
        <Button
          id="save-button"
          onClick={saveScenario}
          className="gap-2 shadow-lg"
          variant="outline"
          size="lg"
        >
          <Save className="h-5 w-5" />
        </Button>
        
        <Button
          id="compare-button"
          onClick={() => setShowComparison(!showComparison)}
          className="gap-2 shadow-lg"
          variant={showComparison ? "default" : "outline"}
          size="lg"
        >
          <FileText className="h-5 w-5" />
          <Badge variant="secondary" className="ml-1">{scenarios.length}</Badge>
        </Button>
      </div>
      
      {/* Simulation Controls Panel */}
      {showControls && (
        <Card className="absolute bottom-20 left-4 z-10 p-4 w-80 shadow-xl">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">
                {language === "ar" ? "إعدادات المحاكاة" : "Simulation Settings"}
              </h3>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{language === "ar" ? "شدة الأمواج" : "Wave Intensity"}</span>
                <Badge variant="secondary">{(waveIntensity * 100).toFixed(0)}%</Badge>
              </div>
              <Slider
                value={[waveIntensity]}
                onValueChange={(v) => setWaveIntensity(v[0])}
                min={0.1}
                max={2}
                step={0.1}
                className="w-full"
              />
            </div>
            
            <div className="text-xs text-muted-foreground space-y-1">
              <div className="flex justify-between">
                <span>{language === "ar" ? "ارتفاع الموجة:" : "Wave Height:"}</span>
                <span className="font-mono">{(waveIntensity * 3).toFixed(1)}m</span>
              </div>
              <div className="flex justify-between">
                <span>{language === "ar" ? "السرعة:" : "Speed:"}</span>
                <span className="font-mono">{(waveIntensity * 2.5).toFixed(1)}m/s</span>
              </div>
            </div>
          </div>
        </Card>
      )}
      
      {/* Component Explanation Panel */}
      {selectedComponent && (
        <Card className="absolute top-4 left-4 z-10 p-5 w-96 shadow-xl">
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                <h3 className="font-bold text-lg">
                  {explanations[selectedComponent].title}
                </h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedComponent(null)}
              >
                ✕
              </Button>
            </div>
            
            <p className="text-sm text-muted-foreground leading-relaxed">
              {explanations[selectedComponent].description}
            </p>
            
            <div className="border-t pt-3 space-y-1.5">
              <div className="font-semibold text-sm mb-2">
                {language === "ar" ? "المواصفات الفنية:" : "Technical Specifications:"}
              </div>
              {explanations[selectedComponent].specs.map((spec, i) => (
                <div key={i} className="text-xs text-muted-foreground flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                  <span>{spec}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
      
      {/* Performance Analysis Panel */}
      {selectedTurbine && analysis && (
        <Card id="analysis-panel" className="absolute top-4 right-4 z-10 p-5 w-80 shadow-xl">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h3 className="font-bold text-lg">
                {language === "ar" ? "تحليل الأداء" : "Performance Analysis"}
              </h3>
            </div>
            
            <div className="text-sm font-medium text-muted-foreground">
              {selectedTurbine.nameAr && language === "ar" ? selectedTurbine.nameAr : selectedTurbine.name}
            </div>
            
            <div className="space-y-3 pt-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">{language === "ar" ? "الطاقة المولدة:" : "Power Output:"}</span>
                <span className="font-bold text-lg text-primary">{analysis.powerOutput} kW</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm">{language === "ar" ? "الكفاءة الحالية:" : "Current Efficiency:"}</span>
                <span className="font-bold text-lg text-green-500">{analysis.efficiency}%</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm">{language === "ar" ? "طاقة الأمواج:" : "Wave Energy:"}</span>
                <span className="font-bold text-lg text-cyan-500">{analysis.waveEnergy}%</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm">{language === "ar" ? "الفقد الميكانيكي:" : "Mechanical Loss:"}</span>
                <span className="font-bold text-lg text-orange-500">{analysis.mechanicalLoss}%</span>
              </div>
            </div>
          </div>
        </Card>
      )}
      
      {/* Tutorial Overlay */}
      {tutorialActive && (
        <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center">
          <Card className="p-6 max-w-lg mx-4 shadow-2xl">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">{tutorialStep + 1}</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">{steps[tutorialStep].title}</h3>
                    <p className="text-xs text-muted-foreground">
                      {tutorialStep + 1} / {steps.length}
                    </p>
                  </div>
                </div>
              </div>
              
              <p className="text-muted-foreground leading-relaxed">
                {steps[tutorialStep].description}
              </p>
              
              <div className="flex gap-2 pt-2">
                <Button onClick={nextTutorialStep} className="flex-1">
                  {tutorialStep < steps.length - 1 
                    ? (language === "ar" ? "التالي" : "Next")
                    : (language === "ar" ? "إنهاء" : "Finish")}
                </Button>
                <Button onClick={skipTutorial} variant="outline">
                  {language === "ar" ? "تخطي" : "Skip"}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
      
      {/* Scenario Comparison Panel */}
      {showComparison && scenarios.length > 0 && (
        <Card className="absolute top-4 left-1/2 -translate-x-1/2 z-10 p-5 max-w-4xl w-full mx-4 shadow-xl max-h-[80vh] overflow-auto">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">
                {language === "ar" ? "مقارنة السيناريوهات" : "Scenario Comparison"}
              </h3>
              <Button variant="ghost" size="sm" onClick={() => setShowComparison(false)}>
                ✕
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-right p-2">{language === "ar" ? "الاسم" : "Name"}</th>
                    <th className="text-right p-2">{language === "ar" ? "شدة الأمواج" : "Wave Intensity"}</th>
                    <th className="text-right p-2">{language === "ar" ? "الطاقة" : "Power"}</th>
                    <th className="text-right p-2">{language === "ar" ? "الكفاءة" : "Efficiency"}</th>
                    <th className="text-right p-2">{language === "ar" ? "الإجراءات" : "Actions"}</th>
                  </tr>
                </thead>
                <tbody>
                  {scenarios.map((scenario) => (
                    <tr key={scenario.id} className="border-b hover:bg-muted/50">
                      <td className="p-2 font-medium">{scenario.name}</td>
                      <td className="p-2">{(scenario.waveIntensity * 100).toFixed(0)}%</td>
                      <td className="p-2">{scenario.analysis.powerOutput} kW</td>
                      <td className="p-2">{scenario.analysis.efficiency}%</td>
                      <td className="p-2 flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => loadScenario(scenario)}>
                          {language === "ar" ? "تحميل" : "Load"}
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => deleteScenario(scenario.id)}>
                          {language === "ar" ? "حذف" : "Delete"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Card>
      )}
      
      {/* Simple Instructions */}
      <div className="absolute bottom-4 right-4 z-10 bg-background/95 backdrop-blur-sm px-4 py-2 rounded-lg border border-border text-xs shadow-lg">
        {language === "ar" 
          ? "💡 انقر على أي جزء من التوربين لعرض التفاصيل"
          : "💡 Click any turbine component for details"}
      </div>
    </div>
  );
}
