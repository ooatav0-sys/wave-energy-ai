import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Zap, Activity, Waves, AlertTriangle } from "lucide-react";
import OceanScene3D from "@/components/OceanScene3D";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useLanguage } from "@/contexts/LanguageContext";
import InfoPanel from "@/components/InfoPanel";
import { useState } from "react";

export default function Dashboard() {
  const { t, language } = useLanguage();
  const [selectedTurbineId, setSelectedTurbineId] = useState<number | undefined>();
  
  const { data: turbines } = trpc.turbines.list.useQuery();
  const { data: totalOutput } = trpc.energy.totalOutput.useQuery();
  const { data: alerts } = trpc.alerts.unread.useQuery({ limit: 5 });
  
  const selectedTurbine = turbines?.find(t => t.id === selectedTurbineId);
  const { data: latestEnergy } = trpc.energy.latest.useQuery(
    { turbineId: selectedTurbineId! },
    { enabled: !!selectedTurbineId, refetchInterval: 5000 }
  );
  const { data: latestWave } = trpc.waves.latest.useQuery(
    { turbineId: selectedTurbineId! },
    { enabled: !!selectedTurbineId, refetchInterval: 5000 }
  );
  
  const endDate = new Date();
  const startDate = new Date(endDate.getTime() - 24 * 60 * 60 * 1000);
  const { data: energyHistory } = trpc.energy.range.useQuery(
    {
      turbineId: selectedTurbineId || 1,
      startDate,
      endDate,
    },
    { enabled: !!turbines?.length }
  );
  
  const activeTurbines = turbines?.filter(t => t.status === "active").length || 0;
  const totalTurbines = turbines?.length || 0;
  const avgEfficiency = turbines && turbines.length > 0
    ? turbines.reduce((sum, t) => sum + (t.efficiency || 0), 0) / turbines.length
    : 0;
  const activeAlerts = alerts?.length || 0;

  const chartData = energyHistory?.map(e => ({
    time: new Date(e.timestamp).toLocaleTimeString(language === "ar" ? "ar-SA" : "en-US", { hour: '2-digit', minute: '2-digit' }),
    power: e.powerOutput,
  })) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-background/95">
      <div className="container py-8">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-cyan-500 to-teal-500 bg-clip-text text-transparent">
              {t("dashboard.title")}
            </h1>
            <p className="text-muted-foreground mt-2 text-lg">
              {t("dashboard.subtitle")}
            </p>
          </div>
          <InfoPanel
            title={language === "ar" ? "حول النظام" : "About the System"}
            content={t("explain.turbine")}
            technicalDetails={[
              { label: language === "ar" ? "نوع التوربين" : "Turbine Type", value: "Marine Tidal" },
              { label: language === "ar" ? "القدرة القصوى" : "Max Capacity", value: "2500 kW" },
              { label: language === "ar" ? "عمق التشغيل" : "Operating Depth", value: "15-30m" },
              { label: language === "ar" ? "العمر الافتراضي" : "Lifespan", value: "25 years" },
            ]}
          />
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          <Card className="engineering-card p-6 hover:glow-active transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <Zap className="h-6 w-6 text-blue-500" />
                </div>
                <InfoPanel
                  title={t("dashboard.total_output")}
                  content={language === "ar" 
                    ? "إجمالي الطاقة الكهربائية المولدة من جميع التوربينات خلال آخر 24 ساعة. يتم قياسها بالكيلووات (kW) وتعتمد على قوة الأمواج وسرعة التيارات البحرية."
                    : "Total electrical energy generated from all turbines in the last 24 hours. Measured in kilowatts (kW) and depends on wave strength and ocean current speed."}
                  technicalDetails={[
                    { label: language === "ar" ? "الحد الأقصى" : "Peak", value: "12,500 kW" },
                    { label: language === "ar" ? "المتوسط" : "Average", value: "8,395 kW" },
                  ]}
                />
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground">
                {t("dashboard.total_output")}
              </h3>
              <p className="text-3xl font-bold metric-display text-foreground">
                {(totalOutput || 0).toFixed(1)} <span className="text-lg text-muted-foreground">{t("unit.kw")}</span>
              </p>
              <p className="text-xs text-muted-foreground">{t("dashboard.last_24h")}</p>
            </div>
          </Card>

          <Card className="engineering-card p-6 hover:glow-active transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <Activity className="h-6 w-6 text-green-500" />
                </div>
                <InfoPanel
                  title={t("dashboard.active_turbines")}
                  content={language === "ar"
                    ? "عدد التوربينات التي تعمل حالياً وتولد الطاقة. التوربينات النشطة تدور بشكل مستمر لتحويل طاقة الأمواج إلى كهرباء."
                    : "Number of turbines currently operating and generating power. Active turbines rotate continuously to convert wave energy into electricity."}
                />
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground">
                {t("dashboard.active_turbines")}
              </h3>
              <p className="text-3xl font-bold metric-display text-foreground">
                {activeTurbines} / {totalTurbines}
              </p>
              <p className="text-xs text-muted-foreground">{t("dashboard.currently_operating")}</p>
            </div>
          </Card>

          <Card className="engineering-card p-6 hover:glow-active transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-cyan-500/10">
                  <Waves className="h-6 w-6 text-cyan-500" />
                </div>
                <InfoPanel
                  title={t("dashboard.efficiency")}
                  content={t("explain.efficiency")}
                  technicalDetails={[
                    { label: language === "ar" ? "الكفاءة المثلى" : "Optimal", value: ">75%" },
                    { label: language === "ar" ? "مقبول" : "Acceptable", value: "60-75%" },
                    { label: language === "ar" ? "منخفض" : "Low", value: "<60%" },
                  ]}
                />
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground">
                {t("dashboard.efficiency")}
              </h3>
              <p className="text-3xl font-bold metric-display text-foreground">
                {avgEfficiency.toFixed(1)}<span className="text-lg text-muted-foreground">%</span>
              </p>
              <p className="text-xs text-muted-foreground">{t("dashboard.system_average")}</p>
            </div>
          </Card>

          <Card className="engineering-card p-6 hover:glow-active transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-yellow-500/10">
                  <AlertTriangle className="h-6 w-6 text-yellow-500" />
                </div>
                <InfoPanel
                  title={t("dashboard.alerts")}
                  content={language === "ar"
                    ? "التنبيهات النشطة التي تتطلب انتباهك. قد تشمل تنبيهات الصيانة، الأعطال، أو فرص التشغيل المثلى."
                    : "Active alerts requiring your attention. May include maintenance alerts, malfunctions, or optimal operation opportunities."}
                />
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground">
                {t("dashboard.alerts")}
              </h3>
              <p className="text-3xl font-bold metric-display text-foreground">
                {activeAlerts}
              </p>
              <p className="text-xs text-muted-foreground">{t("dashboard.requires_attention")}</p>
            </div>
          </Card>
        </div>

        {/* 3D Visualization */}
        <Card className="engineering-card mt-8 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-foreground">{t("3d.title")}</h2>
              <p className="text-sm text-muted-foreground mt-1">{t("3d.description")}</p>
            </div>
            <InfoPanel
              title={language === "ar" ? "التصور ثلاثي الأبعاد" : "3D Visualization"}
              content={language === "ar"
                ? "عرض تفاعلي يوضح موقع التوربينات في المحيط. يمكنك التحكم بالكاميرا بالماوس: اسحب للدوران، عجلة الماوس للتقريب/التبعيد. انقر على أي توربين لعرض تفاصيله الفنية."
                : "Interactive view showing turbine locations in the ocean. Control the camera with mouse: drag to rotate, scroll to zoom. Click any turbine to view its technical details."}
              technicalDetails={[
                { label: language === "ar" ? "التحكم" : "Controls", value: language === "ar" ? "ماوس + لوحة مفاتيح" : "Mouse + Keyboard" },
                { label: language === "ar" ? "التحديث" : "Update Rate", value: "60 FPS" },
              ]}
            />
          </div>
          <div className="h-[500px] rounded-lg overflow-hidden border border-border/50">
            {turbines && (
              <OceanScene3D
                turbines={turbines}
                selectedTurbineId={selectedTurbineId}
                onTurbineSelect={setSelectedTurbineId}
              />
            )}
          </div>
        </Card>

        {/* Charts & Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          <Card className="engineering-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">{t("chart.power_output")}</h3>
              <InfoPanel
                title={t("chart.power_output")}
                content={language === "ar"
                  ? "رسم بياني يوضح الطاقة المولدة على مدار آخر 24 ساعة. تظهر التقلبات بناءً على قوة الأمواج وظروف البحر."
                  : "Chart showing power generation over the last 24 hours. Fluctuations reflect wave strength and sea conditions."}
              />
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="powerGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.20 220)" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="oklch(0.65 0.20 220)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.03 240)" />
                <XAxis 
                  dataKey="time" 
                  stroke="oklch(0.65 0.02 240)"
                  tick={{ fill: 'oklch(0.65 0.02 240)' }}
                />
                <YAxis 
                  stroke="oklch(0.65 0.02 240)"
                  tick={{ fill: 'oklch(0.65 0.02 240)' }}
                  label={{ value: t("unit.kw"), angle: -90, position: 'insideLeft', fill: 'oklch(0.65 0.02 240)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'oklch(0.15 0.02 240)', 
                    border: '1px solid oklch(0.25 0.03 240)',
                    borderRadius: '8px'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="power" 
                  stroke="oklch(0.65 0.20 220)" 
                  fillOpacity={1}
                  fill="url(#powerGradient)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          <Card className="engineering-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">
                {selectedTurbine ? selectedTurbine.name : t("3d.select_turbine")}
              </h3>
            </div>
            {selectedTurbine ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 rounded-lg bg-background/50">
                  <span className="text-sm text-muted-foreground">{t("turbine.status")}</span>
                  <span className="text-lg font-bold metric-display text-foreground capitalize">
                    {t(`status.${selectedTurbine.status}`)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 rounded-lg bg-background/50">
                  <span className="text-sm text-muted-foreground">{t("turbine.power_output")}</span>
                  <span className="text-lg font-bold metric-display text-foreground">
                    {latestEnergy?.powerOutput.toFixed(1) || "0"} {t("unit.kw")}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 rounded-lg bg-background/50">
                  <span className="text-sm text-muted-foreground">{t("turbine.efficiency")}</span>
                  <span className="text-lg font-bold metric-display text-foreground">
                    {selectedTurbine.efficiency.toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 rounded-lg bg-background/50">
                  <span className="text-sm text-muted-foreground">{t("turbine.rotation_speed")}</span>
                  <span className="text-lg font-bold metric-display text-foreground">
                    {selectedTurbine.rotationSpeed.toFixed(1)} {t("unit.rpm")}
                  </span>
                </div>
                {latestWave && (
                  <div className="flex justify-between items-center p-4 rounded-lg bg-background/50">
                    <span className="text-sm text-muted-foreground">{t("wave.height")}</span>
                    <span className="text-lg font-bold metric-display text-foreground">
                      {latestWave.waveHeight.toFixed(2)} {t("unit.meter")}
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                <Waves className="h-16 w-16 mb-4 opacity-30" />
                <p className="text-center">{t("3d.click_to_select")}</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
