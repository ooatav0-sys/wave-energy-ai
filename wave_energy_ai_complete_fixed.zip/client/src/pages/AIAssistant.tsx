import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Send, Bot, User, Loader2 } from "lucide-react";
import { Streamdown } from "streamdown";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";

export default function AIAssistant() {
  const { user, isAuthenticated } = useAuth();
  const { language, t } = useLanguage();
  const [message, setMessage] = useState("");
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const utils = trpc.useUtils();
  
  // Fetch chat sessions
  const { data: sessions } = trpc.chat.sessions.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  // Fetch messages for current session
  const { data: messages, isLoading: messagesLoading } = trpc.chat.messages.useQuery(
    { sessionId: currentSessionId! },
    { enabled: !!currentSessionId }
  );
  
  // Create new session mutation
  const createSession = trpc.chat.createSession.useMutation({
    onSuccess: async () => {
      // Refetch sessions to get the new one
      const updatedSessions = await utils.chat.sessions.fetch();
      if (updatedSessions && updatedSessions.length > 0) {
        setCurrentSessionId(updatedSessions[0].id);
      }
    },
  });
  
  // Send message mutation
  const sendMessage = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      utils.chat.messages.invalidate({ sessionId: currentSessionId! });
      utils.chat.sessions.invalidate();
      setMessage("");
    },
    onError: (error) => {
      toast.error("Failed to send message: " + error.message);
    },
  });
  
  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  // Create initial session if none exists
  useEffect(() => {
    if (isAuthenticated && !currentSessionId && sessions && sessions.length > 0) {
      setCurrentSessionId(sessions[0].id);
    }
  }, [isAuthenticated, currentSessionId, sessions]);
  
  const handleSendMessage = async () => {
    if (!message.trim()) return;
    
    if (!currentSessionId) {
      // Create new session first
      await createSession.mutateAsync({ language });
    }
    
    if (currentSessionId) {
      sendMessage.mutate({
        sessionId: currentSessionId,
        message: message.trim(),
      });
    }
  };
  
  const handleNewChat = () => {
    createSession.mutate({ language });
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 dark:from-slate-950 dark:via-blue-950 dark:to-cyan-950">
        <div className="container py-8">
          <Card>
            <CardHeader>
              <CardTitle>AI Assistant</CardTitle>
              <CardDescription>Please log in to use the AI assistant</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 dark:from-slate-950 dark:via-blue-950 dark:to-cyan-950">
      <div className="container py-8">
        <div className="max-w-5xl mx-auto">
          <div className="mb-6 space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              {t("nav.ai_assistant")}
            </h1>
            <p className="text-muted-foreground">
              Ask questions about energy data, turbine performance, and get AI-powered insights
            </p>
          </div>
          
          <div className="grid gap-6 lg:grid-cols-[250px_1fr]">
            {/* Sidebar - Chat History */}
            <Card className="h-fit">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Conversations</CardTitle>
                  <Button size="sm" onClick={handleNewChat} disabled={createSession.isPending}>
                    New Chat
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {sessions?.map((session) => (
                  <button
                    key={session.id}
                    onClick={() => setCurrentSessionId(session.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      currentSessionId === session.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-accent"
                    }`}
                  >
                    <p className="text-sm font-medium truncate">
                      {session.title || "New Conversation"}
                    </p>
                    <p className="text-xs opacity-70">
                      {new Date(session.createdAt).toLocaleDateString()}
                    </p>
                  </button>
                ))}
                
                {(!sessions || sessions.length === 0) && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No conversations yet
                  </p>
                )}
              </CardContent>
            </Card>
            
            {/* Main Chat Area */}
            <Card className="flex flex-col h-[calc(100vh-12rem)]">
              <CardHeader>
                <CardTitle>Chat with AI Assistant</CardTitle>
                <CardDescription>
                  Get insights about turbine performance, energy forecasts, and optimization recommendations
                </CardDescription>
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col overflow-hidden">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-4">
                  {messagesLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : messages && messages.length > 0 ? (
                    messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-3 ${
                          msg.role === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        {msg.role === "assistant" && (
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                            <Bot className="h-5 w-5 text-primary-foreground" />
                          </div>
                        )}
                        
                        <div
                          className={`max-w-[80%] rounded-lg p-4 ${
                            msg.role === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          {msg.role === "assistant" ? (
                            <div className="prose prose-sm dark:prose-invert max-w-none">
                              <Streamdown>{msg.content}</Streamdown>
                            </div>
                          ) : (
                            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                          )}
                        </div>
                        
                        {msg.role === "user" && (
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                            <User className="h-5 w-5 text-accent-foreground" />
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <div className="text-center space-y-4">
                        <Bot className="h-16 w-16 mx-auto opacity-50" />
                        <div>
                          <p className="text-lg font-medium">Start a conversation</p>
                          <p className="text-sm">Ask me anything about your wave energy system</p>
                        </div>
                        <div className="text-left max-w-md mx-auto space-y-2">
                          <p className="text-sm font-medium">Example questions:</p>
                          <ul className="text-sm space-y-1 list-disc list-inside">
                            <li>What is the current efficiency of Turbine Alpha?</li>
                            <li>Show me the power output forecast for next week</li>
                            <li>Which turbine needs maintenance?</li>
                            <li>Analyze the wave conditions for optimal operation</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {sendMessage.isPending && (
                    <div className="flex gap-3 justify-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                        <Bot className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <div className="bg-muted rounded-lg p-4">
                        <Loader2 className="h-5 w-5 animate-spin" />
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
                
                {/* Input */}
                <div className="flex gap-2">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    disabled={sendMessage.isPending}
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!message.trim() || sendMessage.isPending}
                    size="icon"
                  >
                    {sendMessage.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
